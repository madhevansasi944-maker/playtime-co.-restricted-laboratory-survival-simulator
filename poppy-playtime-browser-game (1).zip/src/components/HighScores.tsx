import { useState, useEffect } from 'react';
import { Trophy, Trash2, Clock, Zap } from 'lucide-react';

export interface ScoreEntry {
  id: string;
  name: string;
  score: number;
  timeSurvived: number;
  toysAssembled: number;
  difficulty: 'normal' | 'hard' | 'nightmare';
  date: string;
}

const DEFAULT_SCORES: ScoreEntry[] = [
  { id: '1', name: 'Leith Pierre', score: 12500, timeSurvived: 180, toysAssembled: 8, difficulty: 'nightmare', date: '1991-10-12' },
  { id: '2', name: 'Stella Grey', score: 7800, timeSurvived: 120, toysAssembled: 5, difficulty: 'hard', date: '2026-03-01' },
  { id: '3', name: 'Rich Avery', score: 5400, timeSurvived: 90, toysAssembled: 3, difficulty: 'normal', date: '2026-03-02' },
  { id: '4', name: 'Player One', score: 3200, timeSurvived: 60, toysAssembled: 2, difficulty: 'normal', date: '2026-03-03' },
];

export function getHighScores(): ScoreEntry[] {
  try {
    const data = localStorage.getItem('poppy_highscores');
    if (!data) {
      localStorage.setItem('poppy_highscores', JSON.stringify(DEFAULT_SCORES));
      return DEFAULT_SCORES;
    }
    return JSON.parse(data);
  } catch (e) {
    return DEFAULT_SCORES;
  }
}

export function saveHighScore(score: Omit<ScoreEntry, 'id' | 'date'>) {
  try {
    const scores = getHighScores();
    const newEntry: ScoreEntry = {
      ...score,
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString().split('T')[0],
    };
    const updated = [...scores, newEntry]
      .sort((a, b) => b.score - a.score)
      .slice(0, 10); // Keep top 10
    localStorage.setItem('poppy_highscores', JSON.stringify(updated));
    return updated;
  } catch (e) {
    console.error("Failed to save score:", e);
    return [];
  }
}

export function clearHighScores(): ScoreEntry[] {
  try {
    localStorage.setItem('poppy_highscores', JSON.stringify([]));
    return [];
  } catch (e) {
    return [];
  }
}

interface HighScoresProps {
  currentScore?: number;
  onClose?: () => void;
}

export default function HighScores({ currentScore, onClose }: HighScoresProps) {
  const [scores, setScores] = useState<ScoreEntry[]>([]);

  useEffect(() => {
    setScores(getHighScores());
  }, []);

  // Format score nicely if available
  const displayLastScore = currentScore !== undefined && currentScore > 0;

  const handleReset = () => {
    if (confirm("Are you sure you want to wipe the Playtime Co. employee archives (high scores)?")) {
      const empty = clearHighScores();
      setScores(empty);
    }
  };

  const getDifficultyBadgeColor = (diff: ScoreEntry['difficulty']) => {
    switch (diff) {
      case 'nightmare': return 'bg-red-950/80 text-red-400 border border-red-500/50';
      case 'hard': return 'bg-amber-950/80 text-amber-400 border border-amber-500/50';
      default: return 'bg-blue-950/80 text-blue-400 border border-blue-500/50';
    }
  };

  return (
    <div className="w-full max-w-2xl bg-zinc-950/95 border-2 border-zinc-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden backdrop-blur-md">
      {/* Decorative hazardous stripes */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-yellow-500 via-zinc-900 to-yellow-500 bg-[size:40px_10px] animate-[pulse_2s_infinite]" />

      <div className="flex items-center justify-between mb-6 mt-2">
        <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-amber-400 to-red-500 flex items-center gap-2 tracking-wider">
          <Trophy className="w-7 h-7 text-yellow-400 animate-bounce" />
          PLAYTIME CO. HIGH SCORES
        </h2>
        {onClose && (
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold transition"
          >
            Back
          </button>
        )}
      </div>

      {displayLastScore && (
        <div className="mb-6 p-4 rounded-xl bg-gradient-to-r from-yellow-600/20 via-amber-600/20 to-red-600/20 border border-yellow-500/30 flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-yellow-500/20 flex items-center justify-center text-yellow-400 text-xl font-bold">
              ★
            </div>
            <div>
              <p className="text-xs text-yellow-500 uppercase tracking-widest font-extrabold">Your Latest Escape Score</p>
              <p className="text-xl font-black text-white font-mono">{currentScore.toLocaleString()} pts</p>
            </div>
          </div>
          <span className="text-[10px] bg-yellow-500 text-zinc-950 px-2 py-1 rounded font-black tracking-widest uppercase animate-bounce">
            NEW RECORD!
          </span>
        </div>
      )}

      <div className="overflow-x-auto max-h-[350px] overflow-y-auto pr-1">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-zinc-800 text-zinc-400 text-xs tracking-widest uppercase">
              <th className="py-2 px-3">Rank</th>
              <th className="py-2 px-3">Employee Name</th>
              <th className="py-2 px-3">Difficulty</th>
              <th className="py-2 px-3 text-center">Toys</th>
              <th className="py-2 px-3 text-right">Score</th>
            </tr>
          </thead>
          <tbody>
            {scores.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-12 text-center text-zinc-500 italic">
                  No records found in database. Start a game to log the first record!
                </td>
              </tr>
            ) : (
              scores.map((score, idx) => (
                <tr
                  key={score.id}
                  className={`border-b border-zinc-900 transition-colors duration-150 group ${
                    idx === 0
                      ? 'bg-yellow-500/10 text-yellow-300 font-bold hover:bg-yellow-500/15'
                      : idx === 1
                      ? 'bg-slate-300/5 text-slate-300 hover:bg-slate-300/10'
                      : idx === 2
                      ? 'bg-amber-600/5 text-amber-500 hover:bg-amber-600/10'
                      : 'text-zinc-400 hover:bg-zinc-900/50'
                  }`}
                >
                  <td className="py-3 px-3 flex items-center gap-2">
                    {idx === 0 ? (
                      <span className="flex items-center justify-center w-6 h-6 bg-yellow-500 text-black text-xs font-black rounded-full shadow">
                        1st
                      </span>
                    ) : idx === 1 ? (
                      <span className="flex items-center justify-center w-6 h-6 bg-slate-400 text-black text-xs font-black rounded-full shadow">
                        2nd
                      </span>
                    ) : idx === 2 ? (
                      <span className="flex items-center justify-center w-6 h-6 bg-amber-600 text-white text-xs font-black rounded-full shadow">
                        3rd
                      </span>
                    ) : (
                      <span className="text-zinc-600 pl-2 text-sm">{idx + 1}</span>
                    )}
                  </td>
                  <td className="py-3 px-3 font-mono truncate max-w-[150px]">
                    {score.name}
                  </td>
                  <td className="py-3 px-3">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-extrabold uppercase ${getDifficultyBadgeColor(score.difficulty)}`}>
                      {score.difficulty}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-center font-mono font-bold text-zinc-300">
                    {score.toysAssembled}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-lg font-black tracking-tight">
                    {score.score.toLocaleString()}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex justify-between items-center pt-4 border-t border-zinc-800 text-xs text-zinc-500">
        <div className="flex gap-4">
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-zinc-400" />
            Survival-driven scoring
          </span>
          <span className="flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-yellow-500 animate-pulse" />
            Connect Fuse Boxes for Huge Bonuses!
          </span>
        </div>
        <button
          onClick={handleReset}
          className="flex items-center gap-1 px-2.5 py-1 text-zinc-600 hover:text-red-400 transition hover:bg-red-500/5 rounded font-semibold"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Clear Log
        </button>
      </div>
    </div>
  );
}
