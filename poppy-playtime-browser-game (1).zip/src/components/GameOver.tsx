import { useState } from 'react';
import { RotateCcw, Home, Trophy, Award, Calendar, Timer } from 'lucide-react';
import { saveHighScore } from './HighScores';

interface GameOverProps {
  score: number;
  timeSurvived: number;
  toysAssembled: number;
  difficulty: 'normal' | 'hard' | 'nightmare';
  playerName: string;
  onRestart: () => void;
  onGoHome: () => void;
  onViewHighScores: () => void;
}

export default function GameOver({
  score,
  timeSurvived,
  toysAssembled,
  difficulty,
  playerName,
  onRestart,
  onGoHome,
  onViewHighScores,
}: GameOverProps) {
  const [hasSaved, setHasSaved] = useState(false);

  const handleSaveScore = () => {
    if (hasSaved) return;
    saveHighScore({
      name: playerName,
      score,
      timeSurvived,
      toysAssembled,
      difficulty,
    });
    setHasSaved(true);
  };

  return (
    <div className="w-full max-w-xl bg-zinc-950 border-2 border-red-900 rounded-3xl p-8 shadow-[0_0_50px_rgba(220,38,38,0.25)] relative overflow-hidden backdrop-blur-md">
      {/* Background hazard line accent */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-red-600 via-zinc-900 to-red-600 bg-[size:40px_10px]" />

      {/* Skull background emblem or subtle lights */}
      <div className="absolute -top-12 -left-12 w-64 h-64 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="text-center mb-6">
        <h2 className="text-4xl font-black tracking-widest text-red-500 drop-shadow-[0_0_15px_rgba(220,38,38,0.4)] uppercase">
          YOU GOT CAUGHT!
        </h2>
        <p className="text-zinc-500 font-mono text-xs mt-1 uppercase tracking-widest">
          Technician {playerName} was terminated by Playtime Co. toys.
        </p>
      </div>

      {/* Stats Summary Grid */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {/* Score Block */}
        <div className="bg-zinc-900/50 border border-zinc-800/80 p-4 rounded-xl flex flex-col items-center justify-center">
          <Award className="w-5 h-5 text-yellow-400 mb-1" />
          <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-black">Score</span>
          <span className="text-xl font-black text-white font-mono">{score.toLocaleString()}</span>
        </div>

        {/* Time Block */}
        <div className="bg-zinc-900/50 border border-zinc-800/80 p-4 rounded-xl flex flex-col items-center justify-center">
          <Timer className="w-5 h-5 text-blue-400 mb-1" />
          <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-black">Survived</span>
          <span className="text-xl font-black text-white font-mono">{timeSurvived}s</span>
        </div>

        {/* Toys Block */}
        <div className="bg-zinc-900/50 border border-zinc-800/80 p-4 rounded-xl flex flex-col items-center justify-center">
          <Calendar className="w-5 h-5 text-purple-400 mb-1" />
          <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-black">Toys Done</span>
          <span className="text-xl font-black text-white font-mono">{toysAssembled}</span>
        </div>
      </div>

      {/* Save Score Action Panel */}
      <div className="mb-8 p-4 bg-gradient-to-r from-red-950/20 via-zinc-900/40 to-red-950/20 border border-red-500/20 rounded-2xl flex flex-col items-center justify-between gap-3 text-center">
        <div>
          <h4 className="text-xs text-zinc-400 uppercase tracking-widest font-black mb-1">
            Log Score to Global Archives
          </h4>
          <p className="text-zinc-500 text-[10px] leading-relaxed max-w-xs">
            Submit your record under Technician <strong className="text-yellow-400 font-extrabold">{playerName}</strong> ({difficulty}) to the high scores ledger!
          </p>
        </div>
        <button
          onClick={handleSaveScore}
          disabled={hasSaved}
          className={`px-5 py-2.5 rounded-xl font-extrabold text-xs uppercase tracking-widest transition duration-150 ${
            hasSaved
              ? 'bg-zinc-800 text-zinc-500 border border-zinc-700 cursor-not-allowed'
              : 'bg-yellow-500 hover:bg-yellow-400 text-zinc-950 hover:shadow-[0_0_15px_rgba(234,179,8,0.35)]'
          }`}
        >
          {hasSaved ? '✓ SCORE LOGGED SUCCESSFULLY' : 'SUBMIT PERFORMANCE RECORD'}
        </button>
      </div>

      {/* Navigation and Retry Buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={onRestart}
          className="flex-1 bg-red-600 hover:bg-red-500 text-white font-black tracking-widest uppercase py-3.5 rounded-2xl shadow-lg transition active:scale-[0.98] flex items-center justify-center gap-2"
        >
          <RotateCcw className="w-4 h-4 animate-spin-reverse" />
          INSTANT REPLAY
        </button>

        <button
          onClick={onViewHighScores}
          className="px-5 py-3.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 rounded-2xl font-bold text-xs tracking-wider transition flex items-center justify-center gap-1.5"
        >
          <Trophy className="w-4 h-4 text-yellow-500" />
          LEADERBOARD
        </button>

        <button
          onClick={onGoHome}
          className="px-5 py-3.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 rounded-2xl font-bold text-xs tracking-wider transition flex items-center justify-center gap-1.5"
        >
          <Home className="w-4 h-4 text-zinc-400" />
          MAIN MENU
        </button>
      </div>
    </div>
  );
}
