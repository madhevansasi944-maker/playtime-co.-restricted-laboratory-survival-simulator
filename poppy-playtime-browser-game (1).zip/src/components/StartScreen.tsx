import { useState } from 'react';
import { Play, Trophy, Volume2, VolumeX, Shield, AlertCircle, Sparkles } from 'lucide-react';

interface StartScreenProps {
  onStartGame: (playerName: string, difficulty: 'normal' | 'hard' | 'nightmare') => void;
  onViewHighScores: () => void;
  isMuted: boolean;
  onToggleMute: (muted: boolean) => void;
}

export default function StartScreen({
  onStartGame,
  onViewHighScores,
  isMuted,
  onToggleMute,
}: StartScreenProps) {
  const [playerName, setPlayerName] = useState(() => {
    return 'REC-' + Math.floor(100 + Math.random() * 900);
  });
  const [difficulty, setDifficulty] = useState<'normal' | 'hard' | 'nightmare'>('normal');

  const handleStart = () => {
    const trimmed = playerName.trim();
    const finalName = trimmed ? trimmed : 'REC-91';
    onStartGame(finalName, difficulty);
  };

  const getDifficultyDesc = (diff: typeof difficulty) => {
    switch (diff) {
      case 'nightmare':
        return 'Extreme test. Faster Huggy, faster power grid drain. Best scores.';
      case 'hard':
        return 'Standard survival test. Intruders crawl faster. High difficulty.';
      default:
        return 'Balanced pace. Great for first-time GrabPack technicians.';
    }
  };

  return (
    <div className="w-full max-w-2xl bg-zinc-950 border-2 border-zinc-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden backdrop-blur-md">
      {/* Background hazard line accent */}
      <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-yellow-500 via-zinc-900 to-yellow-500 bg-[size:40px_10px]" />

      {/* Decorative floating factory fog rings */}
      <div className="absolute -top-12 -left-12 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-red-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header Sound Controls */}
      <div className="flex justify-end mb-4">
        <button
          onClick={() => onToggleMute(!isMuted)}
          className="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-300 transition"
          title={isMuted ? 'Unmute' : 'Mute'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-green-400" />}
        </button>
      </div>

      {/* Retro Playtime Logo / Title */}
      <div className="text-center mb-8">
        <div className="inline-block relative">
          <h1 className="text-5xl md:text-6xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-b from-yellow-300 via-amber-400 to-red-600 drop-shadow-[0_4px_12px_rgba(234,179,8,0.3)] select-none">
            POPPY PLAYTIME
          </h1>
          <div className="absolute -top-4 -right-10 bg-red-600 text-white font-black text-[9px] tracking-widest px-2 py-0.5 rounded uppercase rotate-12 animate-pulse shadow-md">
            GRABPACK
          </div>
        </div>
        <p className="text-zinc-500 font-mono text-xs mt-2 uppercase tracking-widest">
          SYSTEM MANUAL: OVERLOAD ARC ESCAPE v2.6.0
        </p>
      </div>

      <div className="space-y-6">
        {/* Name input */}
        <div>
          <label className="block text-zinc-400 text-xs font-black uppercase tracking-wider mb-2 font-mono">
            Technician Employee ID / Name:
          </label>
          <input
            type="text"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value.slice(0, 16))}
            placeholder="Enter Name..."
            className="w-full bg-zinc-900/80 border-2 border-zinc-800 rounded-xl px-4 py-3 text-white font-mono placeholder-zinc-700 focus:outline-none focus:border-yellow-500/50 transition text-lg"
          />
        </div>

        {/* Difficulty Selection */}
        <div>
          <label className="block text-zinc-400 text-xs font-black uppercase tracking-wider mb-2 font-mono">
            System Difficulty Override:
          </label>
          <div className="grid grid-cols-3 gap-3">
            {(['normal', 'hard', 'nightmare'] as const).map((diff) => (
              <button
                key={diff}
                onClick={() => setDifficulty(diff)}
                className={`py-3 px-2 rounded-xl border-2 font-black uppercase text-xs tracking-wider transition duration-150 flex flex-col items-center gap-1.5 ${
                  difficulty === diff
                    ? diff === 'nightmare'
                      ? 'bg-red-950/40 border-red-500 text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.25)]'
                      : diff === 'hard'
                      ? 'bg-amber-950/40 border-amber-500 text-amber-400'
                      : 'bg-indigo-950/40 border-indigo-500 text-indigo-400'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-zinc-700'
                }`}
              >
                <Shield className={`w-4 h-4 ${difficulty === diff ? 'animate-pulse' : ''}`} />
                {diff}
              </button>
            ))}
          </div>
          <p className="text-zinc-500 text-[11px] mt-2 italic flex items-center gap-1 font-medium">
            <AlertCircle className="w-3.5 h-3.5 text-zinc-400" />
            {getDifficultyDesc(difficulty)}
          </p>
        </div>

        {/* Play Action / Start Buttons */}
        <div className="pt-4 flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleStart}
            className="flex-1 bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 hover:to-amber-500 text-zinc-950 font-black tracking-widest uppercase text-base py-4 rounded-2xl shadow-xl transition transform active:scale-[0.98] flex items-center justify-center gap-2.5"
          >
            <Play className="w-5 h-5 fill-current" />
            ACTIVATE GRABPACK
          </button>

          <button
            onClick={onViewHighScores}
            className="px-6 py-4 bg-zinc-900 hover:bg-zinc-800 border-2 border-zinc-800 hover:border-zinc-700 text-zinc-300 rounded-2xl font-bold text-sm tracking-wider transition flex items-center justify-center gap-2"
          >
            <Trophy className="w-4 h-4 text-yellow-400" />
            ARCHIVES
          </button>
        </div>

        {/* Quick Instructions list */}
        <div className="border-t border-zinc-900 pt-5">
          <h3 className="text-zinc-400 font-mono text-xs uppercase tracking-wider mb-2.5 flex items-center gap-1.5 font-black">
            <Sparkles className="w-3.5 h-3.5 text-yellow-500 animate-pulse" />
            SAFETY TRAINING REFRESHER:
          </h3>
          <ul className="text-zinc-500 text-[11px] list-decimal pl-4 space-y-1.5 leading-relaxed font-medium">
            <li>
              Use your <span className="text-blue-400 font-bold">Blue Hand</span> (left mouse click) and <span className="text-red-400 font-bold">Red Hand</span> (right click / space / shift) to grab elements or deflect intruders.
            </li>
            <li>
              Complete the <span className="text-yellow-400 font-bold">Electrical Circuit</span> by latching the Blue Hand into the left wall outlet and the Red Hand into the right wall outlet to trigger a high-voltage wipe!
            </li>
            <li>
              Keep the <span className="text-green-400 font-bold">Power Grid charged</span> by pulling in batteries, or Huggy Wuggy speeds up in complete pitch-black darkness!
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
