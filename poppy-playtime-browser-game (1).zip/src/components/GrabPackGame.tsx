import { useEffect, useRef, useState } from 'react';
import { sound } from '../utils/sound';
import { Volume2, VolumeX, Pause, Play, Zap, Battery, Sparkles, AlertTriangle } from 'lucide-react';

interface GrabPackGameProps {
  difficulty: 'normal' | 'hard' | 'nightmare';
  playerName: string;
  isMuted: boolean;
  onToggleMute: (muted: boolean) => void;
  onGameOver: (finalScore: number, timeSurvived: number, toysAssembled: number) => void;
  onExit: () => void;
}

// Particle Interface
interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
  type: 'spark' | 'smoke' | 'sparkle' | 'glitch' | 'lightning' | 'text';
  text?: string;
}

// Game Items
interface ToyItem {
  id: string;
  type: 'catbee' | 'boogie' | 'poppy' | 'bunzo' | 'huggy';
  name: string;
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
  rotation: number;
  rotSpeed: number;
  pulsePhase: number;
}

interface BatteryItem {
  id: string;
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
  charge: number;
}

interface VHSTapeItem {
  id: string;
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
}

// Monster Interface
interface Monster {
  id: string;
  type: 'huggy' | 'kissy' | 'mommy';
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  maxSpeed: number;
  targetY: number;
  health: number;
  isStunned: boolean;
  stunTimer: number;
  shakeTimer: number;
  phase: number; // for animations
}

// GrabPack Hand Interface
interface GrabHand {
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  originX: number;
  originY: number;
  state: 'idle' | 'shooting' | 'stuck' | 'returning';
  color: 'blue' | 'red';
  speed: number;
  currentLength: number;
  maxLength: number;
  hitTargetId: string | null;
  hitTargetType: 'toy' | 'battery' | 'vhs' | 'socket' | 'valve' | 'monster' | null;
}

// Fuse Sockets
interface FuseSocket {
  id: string;
  type: 'blue' | 'red';
  x: number;
  y: number;
  radius: number;
  isActive: boolean;
  connected: boolean;
}

// Steam Valve
interface SteamValve {
  id: string;
  x: number;
  y: number;
  radius: number;
  active: boolean;
  steamTimer: number; // Duration of active steam blast
}

export default function GrabPackGame({
  difficulty,
  playerName,
  isMuted,
  onToggleMute,
  onGameOver,
  onExit,
}: GrabPackGameProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // Game state
  const [score, setScore] = useState(0);
  const [power, setPower] = useState(100); // 0 - 100
  const [toysCount, setToysCount] = useState(0);
  const [multiplier, setMultiplier] = useState(1);
  const [isPaused, setIsPaused] = useState(false);
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [frenzyActive, setFrenzyActive] = useState(false);
  const [frenzyTime, setFrenzyTime] = useState(0);
  const [scanlines, setScanlines] = useState(true);

  // References for mutable game loop state to avoid react re-render lag
  const stateRef = useRef({
    score: 0,
    power: 100,
    toysCount: 0,
    multiplier: 1,
    timeElapsed: 0,
    isPaused: false,
    frenzyActive: false,
    frenzyTime: 0,
    monsters: [] as Monster[],
    toys: [] as ToyItem[],
    batteries: [] as BatteryItem[],
    vhsTapes: [] as VHSTapeItem[],
    particles: [] as Particle[],
    blueSocket: null as FuseSocket | null,
    redSocket: null as FuseSocket | null,
    valveLeft: null as SteamValve | null,
    valveRight: null as SteamValve | null,
    blueHand: {
      x: 0,
      y: 0,
      targetX: 0,
      targetY: 0,
      originX: 0,
      originY: 0,
      state: 'idle',
      color: 'blue',
      speed: 28,
      currentLength: 0,
      maxLength: 450,
      hitTargetId: null,
      hitTargetType: null,
    } as GrabHand,
    redHand: {
      x: 0,
      y: 0,
      targetX: 0,
      targetY: 0,
      originX: 0,
      originY: 0,
      state: 'idle',
      color: 'red',
      speed: 28,
      currentLength: 0,
      maxLength: 450,
      hitTargetId: null,
      hitTargetType: null,
    } as GrabHand,
    screenShake: 0,
    jumpscareTimer: 0,
    jumpscareMonster: null as Monster | null,
    gameEnded: false,
    width: 800,
    height: 600,
    spawnTimer: 0,
    difficultyMultiplier: 1,
    lastFrameTime: 0,
    electricArcTimer: 0,
    isSaberActive: false, // electric wire completed
  });

  // Handle keys for Red hand (Space / Shift / D / S etc)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (stateRef.current.isPaused || stateRef.current.gameEnded) return;

      if (e.key === ' ' || e.key.toLowerCase() === 'shift' || e.key.toLowerCase() === 'e') {
        e.preventDefault();
        // Fire red hand towards current mouse position
        const canvas = canvasRef.current;
        if (!canvas) return;

        // We track mouse on canvas, but let's shoot Red Hand directly where the cursor is!
        // We'll store mouse coordinates on the window/canvas
        const mouseX = (window as any)._gameMouseX || canvas.width / 2;
        const mouseY = (window as any)._gameMouseY || canvas.height / 2;

        fireHand('red', mouseX, mouseY);
      } else if (e.key.toLowerCase() === 'p' || e.key === 'Escape') {
        togglePause();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Set difficulty config
  useEffect(() => {
    let mult = 1.0;
    if (difficulty === 'hard') mult = 1.4;
    if (difficulty === 'nightmare') mult = 1.8;
    stateRef.current.difficultyMultiplier = mult;
  }, [difficulty]);

  // Sync React state to game logic loop
  useEffect(() => {
    stateRef.current.isPaused = isPaused;
  }, [isPaused]);

  // Track Time Survived
  useEffect(() => {
    if (isPaused || stateRef.current.gameEnded) return;

    const timer = setInterval(() => {
      setTimeElapsed((prev) => {
        const next = prev + 1;
        stateRef.current.timeElapsed = next;
        
        // Award passive survivability points
        addScore(10 * stateRef.current.multiplier);
        
        return next;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isPaused]);

  // Handle Mute setting inside Sound Manager
  useEffect(() => {
    sound.setMute(isMuted);
  }, [isMuted]);

  // Start Ambient Sound on mount
  useEffect(() => {
    sound.startAmbient();
    return () => {
      sound.stopAmbient();
    };
  }, []);

  // Main game loop initialization
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set dimensions
    const resizeCanvas = () => {
      // Use internal resolution for crisp rendering
      canvas.width = 900;
      canvas.height = 700;
      stateRef.current.width = 900;
      stateRef.current.height = 700;

      // Update GrabPack shoulders
      stateRef.current.blueHand.originX = 180;
      stateRef.current.blueHand.originY = 660;
      if (stateRef.current.blueHand.state === 'idle') {
        stateRef.current.blueHand.x = 180;
        stateRef.current.blueHand.y = 610;
      }

      stateRef.current.redHand.originX = 720;
      stateRef.current.redHand.originY = 660;
      if (stateRef.current.redHand.state === 'idle') {
        stateRef.current.redHand.x = 720;
        stateRef.current.redHand.y = 610;
      }
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Initial game entities setup
    setupSockets();
    setupValves();
    spawnInitialEntities();

    let animationId: number;
    stateRef.current.lastFrameTime = performance.now();

    const loop = (timestamp: number) => {
      const deltaTime = Math.min((timestamp - stateRef.current.lastFrameTime) / 1000, 0.1); // cap deltaTime
      stateRef.current.lastFrameTime = timestamp;

      update(deltaTime);
      render(ctx);

      animationId = requestAnimationFrame(loop);
    };

    animationId = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, []);

  // Setup static entities
  const setupSockets = () => {
    stateRef.current.blueSocket = {
      id: 'blue-sock',
      type: 'blue',
      x: 60,
      y: 350,
      radius: 22,
      isActive: true,
      connected: false,
    };
    stateRef.current.redSocket = {
      id: 'red-sock',
      type: 'red',
      x: 840,
      y: 350,
      radius: 22,
      isActive: true,
      connected: false,
    };
  };

  const setupValves = () => {
    stateRef.current.valveLeft = {
      id: 'valve-left',
      x: 120,
      y: 180,
      radius: 20,
      active: true,
      steamTimer: 0,
    };
    stateRef.current.valveRight = {
      id: 'valve-right',
      x: 780,
      y: 180,
      radius: 20,
      active: true,
      steamTimer: 0,
    };
  };

  const spawnInitialEntities = () => {
    // Spawn Huggy Wuggy
    stateRef.current.monsters = [
      {
        id: 'huggy-wuggy',
        type: 'huggy',
        x: 450,
        y: -100,
        width: 130,
        height: 180,
        speed: 16,
        maxSpeed: 45,
        targetY: -100,
        health: 100,
        isStunned: false,
        stunTimer: 0,
        shakeTimer: 0,
        phase: 0,
      },
    ];
  };

  // State manipulation helpers
  const addScore = (amount: number) => {
    stateRef.current.score += amount;
    setScore(stateRef.current.score);
  };

  const addPower = (amount: number) => {
    stateRef.current.power = Math.min(100, Math.max(0, stateRef.current.power + amount));
    setPower(stateRef.current.power);
  };

  const incrementToys = () => {
    stateRef.current.toysCount += 1;
    setToysCount(stateRef.current.toysCount);
    
    // Increment combo multiplier for every 3 toys assembled
    if (stateRef.current.toysCount % 3 === 0) {
      stateRef.current.multiplier += 1;
      setMultiplier(stateRef.current.multiplier);
      triggerTextParticle(450, 400, `MULTIPLIER UP! x${stateRef.current.multiplier}`, '#eab308');
      sound.playPowerRestore();
    }
  };

  // Shoot GrabPack Hand
  const fireHand = (color: 'blue' | 'red', targetX: number, targetY: number) => {
    const hand = color === 'blue' ? stateRef.current.blueHand : stateRef.current.redHand;
    if (hand.state !== 'idle') return; // Cannot shoot if already in action

    // Disconnect socket if shot again
    if (color === 'blue' && stateRef.current.blueSocket?.connected) {
      stateRef.current.blueSocket.connected = false;
    }
    if (color === 'red' && stateRef.current.redSocket?.connected) {
      stateRef.current.redSocket.connected = false;
    }

    // Set hand physics target
    hand.state = 'shooting';
    hand.targetX = targetX;
    hand.targetY = targetY;
    hand.currentLength = 0;
    hand.hitTargetId = null;
    hand.hitTargetType = null;

    sound.playShoot();

    // Spawn cute mechanical smoke sparks at launcher
    for (let i = 0; i < 5; i++) {
      triggerParticle(
        hand.originX,
        hand.originY - 30,
        (Math.random() - 0.5) * 4,
        -Math.random() * 5 - 2,
        color === 'blue' ? '#3b82f6' : '#ef4444',
        3 + Math.random() * 3,
        0.5,
        'spark'
      );
    }
  };

  // Trigger Particle helper
  const triggerParticle = (
    x: number,
    y: number,
    vx: number,
    vy: number,
    color: string,
    size: number,
    life: number,
    type: Particle['type'] = 'spark'
  ) => {
    stateRef.current.particles.push({
      x,
      y,
      vx,
      vy,
      color,
      size,
      life,
      maxLife: life,
      type,
    });
  };

  const triggerTextParticle = (x: number, y: number, text: string, color: string) => {
    stateRef.current.particles.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 1.5,
      vy: -2 - Math.random() * 2,
      color,
      size: 16,
      life: 1.5,
      maxLife: 1.5,
      type: 'text',
      text,
    });
  };

  // Spark electric storm between sockets
  const triggerElectricArc = () => {
    const sockB = stateRef.current.blueSocket;
    const sockR = stateRef.current.redSocket;
    if (!sockB || !sockR) return;

    sound.playElectricZap();
    stateRef.current.screenShake = 18;
    stateRef.current.electricArcTimer = 0.6; // duration of spark animation
    addScore(1500 * stateRef.current.multiplier);

    // Blast all monsters with custom electric wave!
    stateRef.current.monsters.forEach((mon) => {
      mon.health -= 60;
      mon.isStunned = true;
      mon.stunTimer = 3.5; // Stunned for 3.5 seconds
      mon.y = Math.max(-100, mon.y - 180); // Push back significantly
      mon.shakeTimer = 0.8;

      // Spawn text & massive spark storm on the monster
      triggerTextParticle(mon.x, mon.y + 50, "OVERLOAD ZAP! -60 HP", '#60a5fa');
      for (let i = 0; i < 25; i++) {
        triggerParticle(
          mon.x + (Math.random() - 0.5) * mon.width,
          mon.y + (Math.random() - 0.5) * mon.height,
          (Math.random() - 0.5) * 12,
          (Math.random() - 0.5) * 12,
          '#60a5fa',
          2 + Math.random() * 3,
          0.8,
          'lightning'
        );
      }
    });

    // Reset sockets connection state
    sockB.connected = false;
    sockR.connected = false;
    
    // Also snap back GrabPack hands
    if (stateRef.current.blueHand.state === 'stuck') stateRef.current.blueHand.state = 'returning';
    if (stateRef.current.redHand.state === 'stuck') stateRef.current.redHand.state = 'returning';

    // Massive lightning explosion particles along the center axis
    for (let x = sockB.x; x <= sockR.x; x += 30) {
      const yOffset = Math.sin(x * 0.05) * 40 + (350 + (Math.random() - 0.5) * 30);
      triggerParticle(x, yOffset, 0, (Math.random() - 0.5) * 2, '#38bdf8', 3, 0.4, 'lightning');
    }
  };

  // Frame Update Logic
  const update = (dt: number) => {
    if (stateRef.current.gameEnded) return;

    // Handle screen shake decay
    if (stateRef.current.screenShake > 0) {
      stateRef.current.screenShake -= dt * 30;
      if (stateRef.current.screenShake < 0) stateRef.current.screenShake = 0;
    }

    // Handle electric arc animation timer
    if (stateRef.current.electricArcTimer > 0) {
      stateRef.current.electricArcTimer -= dt;
    }

    // Hand jumpscare trigger
    if (stateRef.current.jumpscareTimer > 0) {
      stateRef.current.jumpscareTimer -= dt;
      if (stateRef.current.jumpscareTimer <= 0) {
        stateRef.current.gameEnded = true;
        onGameOver(stateRef.current.score, stateRef.current.timeElapsed, stateRef.current.toysCount);
      }
      return; // Freeze game play updates during jumpscare
    }

    if (stateRef.current.isPaused) return;

    // Decaying Power grid
    const powerDecayRate = (difficulty === 'nightmare' ? 3.8 : difficulty === 'hard' ? 2.8 : 2.0) * (stateRef.current.frenzyActive ? 0.3 : 1);
    addPower(-powerDecayRate * dt);

    // If power reaches zero, Huggy becomes enraged
    const isEnraged = stateRef.current.power <= 0;

    // Spawn logic (toys, batteries, VHS tapes, monsters)
    stateRef.current.spawnTimer += dt;
    const spawnInterval = (difficulty === 'nightmare' ? 2.2 : difficulty === 'hard' ? 2.8 : 3.5) / stateRef.current.multiplier;

    if (stateRef.current.spawnTimer >= spawnInterval) {
      stateRef.current.spawnTimer = 0;
      spawnEntity();
    }

    // Steam valve timers
    if (stateRef.current.valveLeft) {
      if (stateRef.current.valveLeft.steamTimer > 0) {
        stateRef.current.valveLeft.steamTimer -= dt;
        // Emit hot steam particles
        for (let i = 0; i < 4; i++) {
          triggerParticle(
            stateRef.current.valveLeft.x + 30,
            stateRef.current.valveLeft.y + (Math.random() - 0.5) * 20,
            4 + Math.random() * 8,
            -1 + (Math.random() - 0.5) * 2,
            'rgba(240, 240, 250, 0.45)',
            6 + Math.random() * 10,
            0.6,
            'smoke'
          );
        }
      }
    }
    if (stateRef.current.valveRight) {
      if (stateRef.current.valveRight.steamTimer > 0) {
        stateRef.current.valveRight.steamTimer -= dt;
        // Emit steam particles
        for (let i = 0; i < 4; i++) {
          triggerParticle(
            stateRef.current.valveRight.x - 30,
            stateRef.current.valveRight.y + (Math.random() - 0.5) * 20,
            -4 - Math.random() * 8,
            -1 + (Math.random() - 0.5) * 2,
            'rgba(240, 240, 250, 0.45)',
            6 + Math.random() * 10,
            0.6,
            'smoke'
          );
        }
      }
    }

    // Frenzy (VHS) mode timer
    if (stateRef.current.frenzyActive) {
      stateRef.current.frenzyTime -= dt;
      if (stateRef.current.frenzyTime <= 0) {
        stateRef.current.frenzyActive = false;
        stateRef.current.multiplier = Math.max(1, stateRef.current.multiplier - 2);
        setMultiplier(stateRef.current.multiplier);
        setFrenzyActive(false);
      }
    }

    // 1. UPDATE GRABPACK HANDS (BLUE AND RED)
    updateHand(stateRef.current.blueHand, dt);
    updateHand(stateRef.current.redHand, dt);

    // 2. UPDATE MONSTERS
    stateRef.current.monsters.forEach((mon) => {
      // Is steam blowing back this monster?
      const isBlownLeft = stateRef.current.valveLeft && stateRef.current.valveLeft.steamTimer > 0 && mon.x < 450;
      const isBlownRight = stateRef.current.valveRight && stateRef.current.valveRight.steamTimer > 0 && mon.x >= 450;
      
      if (mon.isStunned) {
        mon.stunTimer -= dt;
        if (mon.stunTimer <= 0) {
          mon.isStunned = false;
        }
      }

      if (mon.shakeTimer > 0) {
        mon.shakeTimer -= dt;
      }

      mon.phase += dt * (isEnraged ? 8 : 4);

      // Determine movement target and speed
      let speedMult = 1.0;
      if (mon.isStunned) speedMult = 0.15;
      if (isEnraged) speedMult = 1.8;
      if (stateRef.current.frenzyActive) speedMult = 0.4; // slow down in VHS frenzy
      
      let finalSpeed = mon.speed * stateRef.current.difficultyMultiplier * speedMult;
      
      if (isBlownLeft || isBlownRight) {
        // Blown backward towards vents
        mon.y = Math.max(-100, mon.y - 110 * dt);
      } else {
        // Move towards bottom player position
        mon.y += finalSpeed * dt;
      }

      // Check if monster reaches bottom (JUMPSCARE TRIGGER!)
      if (mon.y >= 560) {
        triggerJumpscare(mon);
      }
    });

    // 3. UPDATE COLLECTIBLES & ITEMS PHYSICS
    stateRef.current.toys.forEach((toy) => {
      toy.x += toy.vx * dt;
      toy.y += toy.vy * dt;
      toy.rotation += toy.rotSpeed * dt;
      toy.pulsePhase += dt * 5;

      // Bounce off walls
      if (toy.x - toy.radius <= 30 || toy.x + toy.radius >= 870) {
        toy.vx *= -1;
      }
    });

    stateRef.current.batteries.forEach((bat) => {
      bat.x += bat.vx * dt;
      bat.y += bat.vy * dt;

      if (bat.x - bat.radius <= 30 || bat.x + bat.radius >= 870) {
        bat.vx *= -1;
      }
    });

    stateRef.current.vhsTapes.forEach((tape) => {
      tape.x += tape.vx * dt;
      tape.y += tape.vy * dt;

      if (tape.x - tape.radius <= 30 || tape.x + tape.radius >= 870) {
        tape.vx *= -1;
      }
    });

    // Filter out off-screen items
    stateRef.current.toys = stateRef.current.toys.filter((toy) => toy.y < 750);
    stateRef.current.batteries = stateRef.current.batteries.filter((bat) => bat.y < 750);
    stateRef.current.vhsTapes = stateRef.current.vhsTapes.filter((tape) => tape.y < 750);

    // 4. UPDATE PARTICLES
    stateRef.current.particles.forEach((part) => {
      part.x += part.vx * dt * 60;
      part.y += part.vy * dt * 60;
      part.life -= dt;
    });

    stateRef.current.particles = stateRef.current.particles.filter((p) => p.life > 0);
  };

  // Update logic for a single GrabPack hand
  const updateHand = (hand: GrabHand, dt: number) => {
    const handShoulderX = hand.originX;
    const handShoulderY = hand.originY;

    if (hand.state === 'idle') {
      // Hover hand back in home position with slight wiggle
      const wiggleY = Math.sin(performance.now() * 0.005) * 5;
      hand.x = handShoulderX;
      hand.y = handShoulderY - 50 + wiggleY;
    } else if (hand.state === 'shooting') {
      // Travel towards click target
      const dx = hand.targetX - handShoulderX;
      const dy = hand.targetY - handShoulderY;
      const distToTarget = Math.sqrt(dx * dx + dy * dy);
      const targetDist = Math.min(distToTarget, hand.maxLength);

      const targetXAdjusted = handShoulderX + (dx / distToTarget) * targetDist;
      const targetYAdjusted = handShoulderY + (dy / distToTarget) * targetDist;

      // Move along trajectory
      const stepX = targetXAdjusted - hand.x;
      const stepY = targetYAdjusted - hand.y;
      const stepDist = Math.sqrt(stepX * stepX + stepY * stepY);

      const travelSpeed = hand.speed * 60 * dt;

      if (stepDist <= travelSpeed) {
        hand.x = targetXAdjusted;
        hand.y = targetYAdjusted;
        
        // Hit point reached without sticking, start returning
        hand.state = 'returning';
      } else {
        hand.x += (stepX / stepDist) * travelSpeed;
        hand.y += (stepY / stepDist) * travelSpeed;
      }

      hand.currentLength = Math.sqrt(
        (hand.x - handShoulderX) * (hand.x - handShoulderX) +
          (hand.y - handShoulderY) * (hand.y - handShoulderY)
      );

      // Perform real-time collision checks while hand is searching
      checkHandCollisions(hand);
    } else if (hand.state === 'stuck') {
      // Sticking to socket or pulling valve
      if (hand.hitTargetType === 'socket') {
        const socket = hand.color === 'blue' ? stateRef.current.blueSocket : stateRef.current.redSocket;
        if (socket) {
          hand.x = socket.x;
          hand.y = socket.y;
        }
      } else if (hand.hitTargetType === 'valve') {
        const valve = hand.color === 'blue' ? stateRef.current.valveLeft : stateRef.current.valveRight;
        if (valve) {
          hand.x = valve.x;
          hand.y = valve.y;
        }
      }
    } else if (hand.state === 'returning') {
      // Pulling items back to player
      const dx = handShoulderX - hand.x;
      const dy = (handShoulderY - 50) - hand.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      const returnSpeed = (hand.speed * 1.5) * 60 * dt;

      if (dist <= returnSpeed) {
        // Returned home, process collected items
        processCollectedItem(hand);
        hand.state = 'idle';
        hand.hitTargetId = null;
        hand.hitTargetType = null;
      } else {
        hand.x += (dx / dist) * returnSpeed;
        hand.y += (dy / dist) * returnSpeed;
        
        // Keep dragged item locked onto hand
        dragHitTarget(hand);
      }

      hand.currentLength = Math.sqrt(
        (hand.x - handShoulderX) * (hand.x - handShoulderX) +
          (hand.y - handShoulderY) * (hand.y - handShoulderY)
      );
    }
  };

  // Drag item attached to returning GrabPack Hand
  const dragHitTarget = (hand: GrabHand) => {
    if (!hand.hitTargetId) return;

    if (hand.hitTargetType === 'toy') {
      const toy = stateRef.current.toys.find((t) => t.id === hand.hitTargetId);
      if (toy) {
        toy.x = hand.x;
        toy.y = hand.y;
      }
    } else if (hand.hitTargetType === 'battery') {
      const bat = stateRef.current.batteries.find((b) => b.id === hand.hitTargetId);
      if (bat) {
        bat.x = hand.x;
        bat.y = hand.y;
      }
    } else if (hand.hitTargetType === 'vhs') {
      const tape = stateRef.current.vhsTapes.find((v) => v.id === hand.hitTargetId);
      if (tape) {
        tape.x = hand.x;
        tape.y = hand.y;
      }
    }
  };

  // Check collision of moving GrabPack Hand with entities
  const checkHandCollisions = (hand: GrabHand) => {
    // 1. COLLISION WITH SOCKETS (Electric Puzzle!)
    const sock = hand.color === 'blue' ? stateRef.current.blueSocket : stateRef.current.redSocket;
    if (sock && sock.isActive && !sock.connected) {
      const dx = hand.x - sock.x;
      const dy = hand.y - sock.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist <= sock.radius + 15) {
        hand.state = 'stuck';
        hand.x = sock.x;
        hand.y = sock.y;
        hand.hitTargetId = sock.id;
        hand.hitTargetType = 'socket';
        sock.connected = true;

        sound.playGrab();
        triggerTextParticle(sock.x, sock.y - 30, "CONNECTED!", hand.color === 'blue' ? '#3b82f6' : '#ef4444');

        // Check if both sockets are now completed!
        if (stateRef.current.blueSocket?.connected && stateRef.current.redSocket?.connected) {
          triggerElectricArc();
        }
        return;
      }
    }

    // 2. COLLISION WITH VALVES (Steam Blow!)
    const valve = hand.color === 'blue' ? stateRef.current.valveLeft : stateRef.current.valveRight;
    if (valve && valve.active) {
      const dx = hand.x - valve.x;
      const dy = hand.y - valve.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist <= valve.radius + 15) {
        hand.state = 'returning'; // valve triggers instantly and snaps back
        valve.steamTimer = 3.5; // active hot steam for 3.5s

        sound.playSteamBlast();
        stateRef.current.screenShake = 10;
        triggerTextParticle(valve.x, valve.y + 40, "STEAM VALVE OPENED!", '#f1f5f9');
        return;
      }
    }

    // 3. COLLISION WITH TOYS (Grab items!)
    for (const toy of stateRef.current.toys) {
      const dx = hand.x - toy.x;
      const dy = hand.y - toy.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist <= toy.radius + 20) {
        hand.state = 'returning';
        hand.hitTargetId = toy.id;
        hand.hitTargetType = 'toy';
        
        sound.playGrab();
        return;
      }
    }

    // 4. COLLISION WITH BATTERIES (Power items!)
    for (const bat of stateRef.current.batteries) {
      const dx = hand.x - bat.x;
      const dy = hand.y - bat.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist <= bat.radius + 20) {
        hand.state = 'returning';
        hand.hitTargetId = bat.id;
        hand.hitTargetType = 'battery';
        
        sound.playGrab();
        return;
      }
    }

    // 5. COLLISION WITH VHS TAPES (Glitch Mode!)
    for (const tape of stateRef.current.vhsTapes) {
      const dx = hand.x - tape.x;
      const dy = hand.y - tape.y;
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist <= tape.radius + 20) {
        hand.state = 'returning';
        hand.hitTargetId = tape.id;
        hand.hitTargetType = 'vhs';
        
        sound.playGrab();
        return;
      }
    }

    // 6. COLLISION WITH MONSTERS (Slap back!)
    for (const mon of stateRef.current.monsters) {
      // AABB overlap check with the monster rectangle
      if (
        hand.x >= mon.x - mon.width / 2 &&
        hand.x <= mon.x + mon.width / 2 &&
        hand.y >= mon.y - mon.height / 2 &&
        hand.y <= mon.y + mon.height / 2
      ) {
        hand.state = 'returning';
        
        // Slap damage & push back!
        const dmg = 25;
        mon.health -= dmg;
        mon.y = Math.max(-100, mon.y - 80); // Slapped backward
        mon.isStunned = true;
        mon.stunTimer = 1.0;
        mon.shakeTimer = 0.4;
        stateRef.current.screenShake = 6;

        sound.playGrab();
        triggerTextParticle(mon.x, mon.y + 30, `SLAP! -${dmg} HP`, '#f43f5e');

        // Spark explosion on slap
        for (let i = 0; i < 8; i++) {
          triggerParticle(
            hand.x,
            hand.y,
            (Math.random() - 0.5) * 6,
            (Math.random() - 0.5) * 6,
            '#eab308',
            2.5,
            0.5,
            'spark'
          );
        }

        // Check if monster died/fled
        if (mon.health <= 0) {
          mon.health = 100; // Reset health
          mon.y = -180; // Flee way up into vent
          addScore(1000 * stateRef.current.multiplier);
          triggerTextParticle(mon.x, mon.y + 60, "DEFEATED! +1,000", '#10b981');
          sound.playPowerRestore();
        }
        return;
      }
    }
  };

  // Process the item grabbed once it reaches back to player
  const processCollectedItem = (hand: GrabHand) => {
    if (!hand.hitTargetId) return;

    if (hand.hitTargetType === 'toy') {
      const idx = stateRef.current.toys.findIndex((t) => t.id === hand.hitTargetId);
      if (idx !== -1) {
        const toy = stateRef.current.toys[idx];
        stateRef.current.toys.splice(idx, 1);
        
        // Scoring
        const scoreGain = 500 * stateRef.current.multiplier;
        addScore(scoreGain);
        incrementToys();
        sound.playToyChime();

        triggerTextParticle(hand.originX, hand.originY - 90, `+${scoreGain} PTS`, '#a855f7');
        triggerTextParticle(hand.originX, hand.originY - 110, `Assembled ${toy.name}!`, '#38bdf8');

        // Confetti fireworks!
        for (let i = 0; i < 15; i++) {
          triggerParticle(
            hand.originX,
            hand.originY - 70,
            (Math.random() - 0.5) * 8,
            -Math.random() * 8 - 2,
            ['#a855f7', '#3b82f6', '#f43f5e', '#eab308'][Math.floor(Math.random() * 4)],
            3 + Math.random() * 4,
            1.2,
            'sparkle'
          );
        }
      }
    } else if (hand.hitTargetType === 'battery') {
      const idx = stateRef.current.batteries.findIndex((b) => b.id === hand.hitTargetId);
      if (idx !== -1) {
        stateRef.current.batteries.splice(idx, 1);
        
        // Charge power grid
        addPower(35); // restore 35% power
        addScore(250 * stateRef.current.multiplier);
        sound.playBatteryCharge();

        triggerTextParticle(hand.originX, hand.originY - 90, "+35% POWER", '#10b981');
        
        // Glowing cyan charging particles
        for (let i = 0; i < 15; i++) {
          triggerParticle(
            hand.originX,
            hand.originY - 70,
            (Math.random() - 0.5) * 6,
            -Math.random() * 7 - 3,
            '#10b981',
            3,
            1.0,
            'lightning'
          );
        }
      }
    } else if (hand.hitTargetType === 'vhs') {
      const idx = stateRef.current.vhsTapes.findIndex((v) => v.id === hand.hitTargetId);
      if (idx !== -1) {
        stateRef.current.vhsTapes.splice(idx, 1);
        
        // Enter Frenzy Mode!
        stateRef.current.frenzyActive = true;
        stateRef.current.frenzyTime = 8.0; // 8 seconds of absolute speed
        stateRef.current.multiplier += 2; // boost combo multipliers
        setMultiplier(stateRef.current.multiplier);
        setFrenzyActive(true);
        setFrenzyTime(8.0);
        sound.playBatteryCharge();

        triggerTextParticle(hand.originX, hand.originY - 90, "FRENZY MODE!", '#eab308');
        triggerTextParticle(hand.originX, hand.originY - 110, "3x MULTIPLIER BOOST", '#f43f5e');

        // Rainbow sparks
        for (let i = 0; i < 20; i++) {
          triggerParticle(
            hand.originX,
            hand.originY - 70,
            (Math.random() - 0.5) * 10,
            -Math.random() * 8 - 4,
            `hsl(${Math.random() * 360}, 90%, 60%)`,
            3.5,
            1.2,
            'glitch'
          );
        }
      }
    }
  };

  // Spawner engine
  const spawnEntity = () => {
    const chance = Math.random();
    
    // 1. Spawning standard toys or batteries
    if (chance < 0.45) {
      // Spawn floating toy
      const toyTypes: { type: ToyItem['type']; name: string }[] = [
        { type: 'catbee', name: 'Cat-Bee' },
        { type: 'boogie', name: 'Boogie Bot' },
        { type: 'poppy', name: 'Poppy Doll' },
        { type: 'bunzo', name: 'Bunzo Bunny' },
      ];
      const choice = toyTypes[Math.floor(Math.random() * toyTypes.length)];

      stateRef.current.toys.push({
        id: Math.random().toString(36).substr(2, 9),
        type: choice.type,
        name: choice.name,
        x: 100 + Math.random() * 700,
        y: -40,
        radius: 24,
        vx: (Math.random() - 0.5) * 80,
        vy: 40 + Math.random() * 60,
        rotation: Math.random() * Math.PI,
        rotSpeed: (Math.random() - 0.5) * 2,
        pulsePhase: 0,
      });
    } else if (chance < 0.8) {
      // Spawn high voltage battery
      stateRef.current.batteries.push({
        id: Math.random().toString(36).substr(2, 9),
        x: 100 + Math.random() * 700,
        y: -40,
        radius: 18,
        vx: (Math.random() - 0.5) * 60,
        vy: 50 + Math.random() * 75,
        charge: 35,
      });
    } else if (chance < 0.9) {
      // Spawn yellow VHS Tape
      stateRef.current.vhsTapes.push({
        id: Math.random().toString(36).substr(2, 9),
        x: 100 + Math.random() * 700,
        y: -40,
        radius: 20,
        vx: (Math.random() - 0.5) * 110,
        vy: 60 + Math.random() * 90,
      });
    }

    // Occasionally spawn another monster to intensify gameplay
    if (stateRef.current.monsters.length < 2 && Math.random() < 0.25) {
      const type = Math.random() > 0.5 ? 'kissy' : 'mommy';
      const xPos = type === 'kissy' ? 220 : 680;
      
      stateRef.current.monsters.push({
        id: `monster-${Date.now()}`,
        type: type,
        x: xPos,
        y: -120,
        width: 110,
        height: 160,
        speed: 14,
        maxSpeed: 38,
        targetY: -120,
        health: 70,
        isStunned: false,
        stunTimer: 0,
        shakeTimer: 0,
        phase: Math.random() * 10,
      });
    }
  };

  // Trigger jumpscare on lose
  const triggerJumpscare = (monster: Monster) => {
    if (stateRef.current.jumpscareTimer > 0) return;

    sound.playJumpscare();
    stateRef.current.screenShake = 35;
    stateRef.current.jumpscareTimer = 1.6; // duration of screams before game-over
    stateRef.current.jumpscareMonster = monster;
  };

  // Mouse move captures coordinates for Red Hand firing
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    // Cache to global-ish reference for spacebar shooter
    (window as any)._gameMouseX = x;
    (window as any)._gameMouseY = y;
  };

  // Click captures (Left click fires Blue hand, Right click fires Red)
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    if (stateRef.current.isPaused || stateRef.current.gameEnded) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    if (e.button === 0) {
      // Left Click fires Blue
      fireHand('blue', x, y);
    } else if (e.button === 2) {
      // Right Click fires Red
      fireHand('red', x, y);
    }
  };

  // Touch triggers for mobile (divided left/right screens)
  const handleCanvasTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (stateRef.current.isPaused || stateRef.current.gameEnded) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    
    // Loop over active touches
    for (let i = 0; i < e.touches.length; i++) {
      const touch = e.touches[i];
      const x = ((touch.clientX - rect.left) / rect.width) * canvas.width;
      const y = ((touch.clientY - rect.top) / rect.height) * canvas.height;

      // Left 50% fires Blue, Right 50% fires Red
      if (x < canvas.width / 2) {
        fireHand('blue', x, y);
      } else {
        fireHand('red', x, y);
      }
    }
  };

  // Context menu prevention
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
  };

  // GRAPHICS RENDER LOOP
  const render = (ctx: CanvasRenderingContext2D) => {
    const w = stateRef.current.width;
    const h = stateRef.current.height;

    ctx.save();
    
    // Screen Shake Offset
    if (stateRef.current.screenShake > 0) {
      const dx = (Math.random() - 0.5) * stateRef.current.screenShake;
      const dy = (Math.random() - 0.5) * stateRef.current.screenShake;
      ctx.translate(dx, dy);
    }

    // 1. Draw Factory Background (Dark metal warehouse atmosphere)
    const powerPct = stateRef.current.power / 100;
    const isDark = powerPct <= 0.01;
    
    // Background gradient depending on power levels
    const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
    if (isDark) {
      bgGrad.addColorStop(0, '#020617'); // near total blackness
      bgGrad.addColorStop(1, '#090d16');
    } else {
      bgGrad.addColorStop(0, '#090d16');
      bgGrad.addColorStop(0.5, '#05070c');
      bgGrad.addColorStop(1, '#0d131f');
    }
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);

    // Hazard Stripes framing on walls
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, 30, h);
    ctx.fillRect(w - 30, 0, 30, h);

    // Hazard yellow/black lines on side guards
    ctx.strokeStyle = '#eab308';
    ctx.lineWidth = 4;
    for (let y = 0; y < h; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(30, y + 20);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(w, y);
      ctx.lineTo(w - 30, y + 20);
      ctx.stroke();
    }

    // Draw horizontal industrial metallic rafters
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 2;
    for (let y = 100; y < h; y += 150) {
      ctx.beginPath();
      ctx.moveTo(30, y);
      ctx.lineTo(w - 30, y);
      ctx.stroke();
    }

    // Draw spooky metal vents at the top (where Huggy climbs down)
    ctx.fillStyle = '#111827';
    ctx.fillRect(380, 0, 140, 40);
    // Vent grate outlines
    ctx.strokeStyle = '#374151';
    ctx.lineWidth = 3;
    ctx.strokeRect(380, 0, 140, 40);
    for (let x = 390; x < 520; x += 15) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + 5, 40);
      ctx.stroke();
    }

    // Side Vents for Kissy / Mommy
    ctx.fillRect(150, 0, 100, 30);
    ctx.strokeRect(150, 0, 100, 30);
    ctx.fillRect(650, 0, 100, 30);
    ctx.strokeRect(650, 0, 100, 30);

    // 2. Draw static electric fuse sockets
    const sockB = stateRef.current.blueSocket;
    if (sockB) {
      ctx.beginPath();
      ctx.arc(sockB.x, sockB.y, sockB.radius, 0, Math.PI * 2);
      ctx.fillStyle = '#1e1b4b';
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = sockB.connected ? '#60a5fa' : '#1d4ed8';
      ctx.stroke();
      
      // Neon glow inner ring
      ctx.beginPath();
      ctx.arc(sockB.x, sockB.y, sockB.radius - 8, 0, Math.PI * 2);
      ctx.fillStyle = sockB.connected ? '#60a5fa' : '#3b82f6';
      ctx.fill();

      // Connector pin
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(sockB.x - 3, sockB.y - 12, 6, 24);

      if (sockB.connected) {
        // Electricity sparkles around it
        drawLightningArc(ctx, sockB.x, sockB.y, sockB.x + (Math.random() - 0.5) * 20, sockB.y + (Math.random() - 0.5) * 20, '#60a5fa');
      }
    }

    const sockR = stateRef.current.redSocket;
    if (sockR) {
      ctx.beginPath();
      ctx.arc(sockR.x, sockR.y, sockR.radius, 0, Math.PI * 2);
      ctx.fillStyle = '#450a0a';
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = sockR.connected ? '#f87171' : '#b91c1c';
      ctx.stroke();
      
      // Neon glow inner ring
      ctx.beginPath();
      ctx.arc(sockR.x, sockR.y, sockR.radius - 8, 0, Math.PI * 2);
      ctx.fillStyle = sockR.connected ? '#f87171' : '#ef4444';
      ctx.fill();

      // Connector pin
      ctx.fillStyle = '#f8fafc';
      ctx.fillRect(sockR.x - 3, sockR.y - 12, 6, 24);

      if (sockR.connected) {
        // Electricity sparkles
        drawLightningArc(ctx, sockR.x, sockR.y, sockR.x + (Math.random() - 0.5) * 20, sockR.y + (Math.random() - 0.5) * 20, '#f87171');
      }
    }

    // 3. Draw Steam Valves
    const valveL = stateRef.current.valveLeft;
    if (valveL) {
      ctx.save();
      ctx.translate(valveL.x, valveL.y);
      // Outer pipe collar
      ctx.fillStyle = '#334155';
      ctx.fillRect(-24, -12, 12, 24);
      // Valve body
      ctx.beginPath();
      ctx.arc(0, 0, valveL.radius, 0, Math.PI * 2);
      ctx.fillStyle = '#475569';
      ctx.fill();
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Turning red handles
      ctx.fillStyle = valveL.steamTimer > 0 ? '#10b981' : '#ef4444';
      for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 2) {
        ctx.beginPath();
        ctx.arc(Math.cos(angle) * (valveL.radius - 2), Math.sin(angle) * (valveL.radius - 2), 6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    const valveR = stateRef.current.valveRight;
    if (valveR) {
      ctx.save();
      ctx.translate(valveR.x, valveR.y);
      // Outer pipe collar
      ctx.fillStyle = '#334155';
      ctx.fillRect(12, -12, 12, 24);
      // Valve body
      ctx.beginPath();
      ctx.arc(0, 0, valveR.radius, 0, Math.PI * 2);
      ctx.fillStyle = '#475569';
      ctx.fill();
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Turning red handles
      ctx.fillStyle = valveR.steamTimer > 0 ? '#10b981' : '#ef4444';
      for (let angle = 0; angle < Math.PI * 2; angle += Math.PI / 2) {
        ctx.beginPath();
        ctx.arc(Math.cos(angle) * (valveR.radius - 2), Math.sin(angle) * (valveR.radius - 2), 6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }

    // 4. DRAW COLLECTIBLES
    // Draw VHS tapes
    stateRef.current.vhsTapes.forEach((tape) => {
      ctx.save();
      ctx.translate(tape.x, tape.y);
      
      // VHS box tape body (Yellow with warning labels)
      ctx.fillStyle = '#eab308';
      ctx.fillRect(-22, -14, 44, 28);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2;
      ctx.strokeRect(-22, -14, 44, 28);

      // Spooky eye or black window sticker
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-14, -8, 28, 16);

      // Warning text pattern (micro yellow strips)
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(-16, -12, 4, 3);
      ctx.fillRect(-8, -12, 4, 3);

      // Magnetic tape reels inside window
      ctx.beginPath();
      ctx.arc(-6, 0, 5, 0, Math.PI * 2);
      ctx.arc(6, 0, 5, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();

      // Neon pulse shadow ring
      ctx.beginPath();
      ctx.arc(0, 0, tape.radius + 6, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(234, 179, 8, 0.35)';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.restore();
    });

    // Draw Batteries
    stateRef.current.batteries.forEach((bat) => {
      ctx.save();
      ctx.translate(bat.x, bat.y);
      
      // Draw battery body (Cyan cylindrical)
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(-10, -18, 20, 36);
      
      // High energy glowing cyan fluid
      ctx.fillStyle = '#10b981';
      ctx.fillRect(-10, 0, 20, 18);

      // Brass top tip
      ctx.fillStyle = '#fbbf24';
      ctx.fillRect(-4, -22, 8, 4);

      // Lightning bolt icon
      ctx.beginPath();
      ctx.moveTo(-2, -6);
      ctx.lineTo(3, -2);
      ctx.lineTo(-1, 0);
      ctx.lineTo(2, 6);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Outer glow pulse
      ctx.beginPath();
      ctx.arc(0, 0, bat.radius + 6, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(16, 185, 129, 0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.restore();
    });

    // Draw Toys
    stateRef.current.toys.forEach((toy) => {
      ctx.save();
      ctx.translate(toy.x, toy.y);
      ctx.rotate(toy.rotation);

      // Pulse scaling
      const scale = 1.0 + Math.sin(toy.pulsePhase) * 0.08;
      ctx.scale(scale, scale);

      // Color/Styling based on specific toy type
      if (toy.type === 'catbee') {
        // Cat-Bee: yellow and black cat-headed insect with cyan wings
        ctx.fillStyle = '#fbbf24'; // bumblebee yellow
        ctx.beginPath();
        ctx.arc(0, 0, 18, 0, Math.PI * 2);
        ctx.fill();
        // Tiger stripes
        ctx.fillStyle = '#000000';
        ctx.fillRect(-6, -18, 12, 4);
        ctx.fillRect(-12, -4, 24, 4);
        ctx.fillRect(-6, 10, 12, 4);
        // Cute cat ears
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.moveTo(-16, -10); ctx.lineTo(-18, -24); ctx.lineTo(-4, -16); ctx.fill();
        ctx.beginPath();
        ctx.moveTo(16, -10); ctx.lineTo(18, -24); ctx.lineTo(4, -16); ctx.fill();
        // Cyan bee wings
        ctx.fillStyle = 'rgba(34, 211, 238, 0.6)';
        ctx.beginPath();
        ctx.ellipse(-18, -12, 14, 6, -Math.PI/6, 0, Math.PI*2);
        ctx.ellipse(18, -12, 14, 6, Math.PI/6, 0, Math.PI*2);
        ctx.fill();
      } else if (toy.type === 'boogie') {
        // Boogie Bot: cute green toy robot with tracks and big eye
        ctx.fillStyle = '#22c55e'; // green body
        ctx.fillRect(-16, -16, 32, 28);
        // Head screen/eye
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(-12, -12, 24, 14);
        ctx.fillStyle = '#22d3ee'; // cyan eye
        ctx.beginPath();
        ctx.arc(0, -5, 5, 0, Math.PI*2);
        ctx.fill();
        // Tread tracks
        ctx.fillStyle = '#475569';
        ctx.fillRect(-18, 12, 36, 6);
      } else if (toy.type === 'bunzo') {
        // Bunzo Bunny: yellow bunny with gold cymbals
        ctx.fillStyle = '#fbbf24'; // bunny yellow
        ctx.beginPath();
        ctx.arc(0, 4, 16, 0, Math.PI*2);
        ctx.fill();
        // Long bunny ears
        ctx.beginPath();
        ctx.ellipse(-8, -15, 6, 16, -0.1, 0, Math.PI*2);
        ctx.ellipse(8, -15, 6, 16, 0.1, 0, Math.PI*2);
        ctx.fill();
        // Gold cymbals
        ctx.fillStyle = '#fbbf24';
        ctx.strokeStyle = '#eab308';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(-16, 8, 8, 0, Math.PI*2);
        ctx.arc(16, 8, 8, 0, Math.PI*2);
        ctx.fill();
        ctx.stroke();
      } else {
        // Poppy Doll: iconic red hair, white porcelain face
        ctx.fillStyle = '#fee2e2'; // white porcelain skin
        ctx.beginPath();
        ctx.arc(0, 0, 16, 0, Math.PI*2);
        ctx.fill();
        // Red curly hair bounding the sides
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(-14, -6, 10, 0, Math.PI*2);
        ctx.arc(14, -6, 10, 0, Math.PI*2);
        ctx.arc(0, -14, 12, 0, Math.PI*2);
        ctx.fill();
        // Blue dress collar and black eyes
        ctx.fillStyle = '#2563eb';
        ctx.beginPath();
        ctx.moveTo(-10, 14); ctx.lineTo(0, 6); ctx.lineTo(10, 14); ctx.fill();
      }

      ctx.restore();
    });

    // 5. DRAW MONSTERS (Huggy, Kissy, Mommy)
    stateRef.current.monsters.forEach((mon) => {
      ctx.save();
      ctx.translate(mon.x, mon.y);

      // Monster shake if hit/stunned
      if (mon.shakeTimer > 0) {
        ctx.translate((Math.random() - 0.5) * 12, (Math.random() - 0.5) * 12);
      }

      const wave = Math.sin(mon.phase) * 6;
      const isRedRage = isDark; // Red flashing eyes in dark mode

      if (mon.type === 'huggy' || mon.type === 'kissy') {
        const primaryColor = mon.type === 'huggy' ? '#1d4ed8' : '#ec4899'; // blue or pink
        const lipsColor = mon.type === 'huggy' ? '#ef4444' : '#f43f5e';

        // Long blue furry limbs
        ctx.strokeStyle = primaryColor;
        ctx.lineWidth = 14;
        ctx.lineCap = 'round';
        
        // Left arm waving
        ctx.beginPath();
        ctx.moveTo(-35, 10);
        ctx.quadraticCurveTo(-65 - wave, 50 + wave, -55, 95);
        ctx.stroke();

        // Right arm waving
        ctx.beginPath();
        ctx.moveTo(35, 10);
        ctx.quadraticCurveTo(65 + wave, 50 + wave, 55, 95);
        ctx.stroke();

        // Left leg slithering
        ctx.beginPath();
        ctx.moveTo(-20, 80);
        ctx.quadraticCurveTo(-35, 130 + wave, -25, 175);
        ctx.stroke();

        // Right leg slithering
        ctx.beginPath();
        ctx.moveTo(20, 80);
        ctx.quadraticCurveTo(35, 130 - wave, 25, 175);
        ctx.stroke();

        // Fuzzy yellow hands/feet caps
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(-55, 95, 10, 0, Math.PI * 2);
        ctx.arc(55, 95, 10, 0, Math.PI * 2);
        ctx.arc(-25, 175, 12, 0, Math.PI * 2);
        ctx.arc(25, 175, 12, 0, Math.PI * 2);
        ctx.fill();

        // Furry torso
        ctx.fillStyle = primaryColor;
        ctx.fillRect(-35, 10, 70, 85);

        // Cute yellow bowtie
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.moveTo(-18, 12); ctx.lineTo(18, 22); ctx.lineTo(18, 12); ctx.lineTo(-18, 22);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(0, 17, 5, 0, Math.PI * 2);
        ctx.fill();

        // Heart-shaped/triangular head
        ctx.beginPath();
        ctx.moveTo(0, -50);
        ctx.bezierCurveTo(-55, -60, -55, -5, 0, 15);
        ctx.bezierCurveTo(55, -5, 55, -60, 0, -50);
        ctx.closePath();
        ctx.fill();

        // Creepy Googly Eyes
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-16, -24, 14, 0, Math.PI * 2);
        ctx.arc(16, -24, 14, 0, Math.PI * 2);
        ctx.fill();

        // Pupils looking at the player!
        ctx.fillStyle = isRedRage ? '#ef4444' : '#000000';
        ctx.beginPath();
        // Slight lazy eye looking downward
        ctx.arc(-14, -22, 6, 0, Math.PI * 2);
        ctx.arc(18, -25, 6, 0, Math.PI * 2);
        ctx.fill();

        // Menacing Wide Red Mouth with Rows of Sharp Yellow Teeth
        ctx.beginPath();
        ctx.arc(0, -2, 28, 0, Math.PI, false);
        ctx.fillStyle = lipsColor; // Lips border
        ctx.fill();

        // Inner dark mouth
        ctx.beginPath();
        ctx.arc(0, -2, 22, 0, Math.PI, false);
        ctx.fillStyle = '#000000';
        ctx.fill();

        // Sharp yellow needle teeth
        ctx.fillStyle = '#fef08a';
        for (let xOffset = -18; xOffset <= 18; xOffset += 6) {
          // Top teeth row
          ctx.beginPath();
          ctx.moveTo(xOffset, -2);
          ctx.lineTo(xOffset - 2, 4);
          ctx.lineTo(xOffset + 2, 4);
          ctx.fill();

          // Bottom teeth row
          ctx.beginPath();
          ctx.moveTo(xOffset, 14);
          ctx.lineTo(xOffset - 2, 8);
          ctx.lineTo(xOffset + 2, 8);
          ctx.fill();
        }
      } else if (mon.type === 'mommy') {
        // Mommy Long Legs: pink spider toy with green eyes
        ctx.fillStyle = '#ec4899'; // bubblegum pink
        ctx.strokeStyle = '#ec4899';
        ctx.lineWidth = 8;

        // Long stretching spidery limbs
        for (let i = 0; i < 4; i++) {
          const side = i < 2 ? -1 : 1;
          const yOff = i % 2 === 0 ? 10 : 35;
          ctx.beginPath();
          ctx.moveTo(side * 20, yOff);
          ctx.quadraticCurveTo(side * (75 + wave), yOff + 40 + wave, side * 50, 150);
          ctx.stroke();
        }

        // Body trunk
        ctx.fillRect(-22, 0, 44, 60);

        // Head
        ctx.beginPath();
        ctx.arc(0, -32, 26, 0, Math.PI * 2);
        ctx.fill();

        // Big green spider eyes
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.arc(-11, -34, 9, 0, Math.PI * 2);
        ctx.arc(11, -34, 9, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(-9, -36, 3, 0, Math.PI * 2);
        ctx.arc(13, -36, 3, 0, Math.PI * 2);
        ctx.fill();

        // Sinister thin smile
        ctx.strokeStyle = '#db2777';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, -18, 12, 0.1, Math.PI - 0.1);
        ctx.stroke();
      }

      // If stunned, draw dizzy sparks around head
      if (mon.isStunned) {
        ctx.strokeStyle = '#eab308';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(0, -68, 25, 8, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = '#fef08a';
        const sparkAngle = (performance.now() * 0.01) % (Math.PI * 2);
        ctx.beginPath();
        ctx.arc(Math.cos(sparkAngle) * 25, -68 + Math.sin(sparkAngle) * 8, 4, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    });

    // 6. DRAW ELECTRIC WIRES / CABLES (From Launcher shoulders to hands)
    drawCable(ctx, stateRef.current.blueHand, '#2563eb', '#60a5fa');
    drawCable(ctx, stateRef.current.redHand, '#dc2626', '#f87171');

    // 7. DRAW GRABPACK HANDS
    drawHandGraphic(ctx, stateRef.current.blueHand);
    drawHandGraphic(ctx, stateRef.current.redHand);

    // 8. DRAW PARTICLES
    stateRef.current.particles.forEach((part) => {
      ctx.save();
      ctx.globalAlpha = part.life / part.maxLife;

      if (part.type === 'text' && part.text) {
        ctx.font = 'bold 16px "Courier New", Courier, monospace';
        ctx.fillStyle = part.color;
        ctx.textAlign = 'center';
        // Stroke outline for maximum legibility on dark background
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 4;
        ctx.strokeText(part.text, part.x, part.y);
        ctx.fillText(part.text, part.x, part.y);
      } else if (part.type === 'lightning') {
        ctx.strokeStyle = part.color;
        ctx.lineWidth = part.size;
        ctx.beginPath();
        ctx.moveTo(part.x, part.y);
        ctx.lineTo(part.x + (Math.random() - 0.5) * 16, part.y + (Math.random() - 0.5) * 16);
        ctx.stroke();
      } else {
        ctx.fillStyle = part.color;
        ctx.beginPath();
        ctx.arc(part.x, part.y, part.size, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    });

    // 9. DRAW ELECTRIC OVERLOAD ARC IN PROGRESS
    if (stateRef.current.electricArcTimer > 0) {
      const sockB = stateRef.current.blueSocket;
      const sockR = stateRef.current.redSocket;
      if (sockB && sockR) {
        // Draw dramatic full-screen zap lightning lines
        ctx.lineWidth = 6;
        ctx.strokeStyle = '#60a5fa';
        ctx.beginPath();
        let curX = sockB.x;
        let curY = sockB.y;
        ctx.moveTo(curX, curY);

        while (curX < sockR.x) {
          curX += 25 + Math.random() * 25;
          curY = sockB.y + (Math.random() - 0.5) * 80;
          ctx.lineTo(curX, curY);
        }
        ctx.lineTo(sockR.x, sockR.y);
        ctx.stroke();

        // Second overlay white lightning line
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#ffffff';
        ctx.beginPath();
        curX = sockB.x;
        curY = sockB.y;
        ctx.moveTo(curX, curY);

        while (curX < sockR.x) {
          curX += 25 + Math.random() * 25;
          curY = sockB.y + (Math.random() - 0.5) * 40;
          ctx.lineTo(curX, curY);
        }
        ctx.lineTo(sockR.x, sockR.y);
        ctx.stroke();
      }
    }

    // 10. DRAW HUD / LAUNCHER BASE
    // Red glowing critical warning borders when power is low
    if (stateRef.current.power < 25) {
      const flash = Math.abs(Math.sin(performance.now() * 0.008));
      ctx.strokeStyle = `rgba(239, 68, 68, ${flash * 0.4})`;
      ctx.lineWidth = 15;
      ctx.strokeRect(0, 0, w, h);
    }

    // Draw bottom command panel
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(30, 640, w - 60, 60);
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 3;
    ctx.strokeRect(30, 640, w - 60, 60);

    // Draw GrabPack shoulder/backpack unit at center
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(380, 610, 140, 50);
    // Warning hazard stripes on backpack
    ctx.fillStyle = '#eab308';
    ctx.fillRect(390, 620, 10, 30);
    ctx.fillRect(410, 620, 10, 30);
    ctx.fillRect(480, 620, 10, 30);
    ctx.fillRect(500, 620, 10, 30);

    // Green charging status orb
    ctx.beginPath();
    ctx.arc(450, 635, 12, 0, Math.PI * 2);
    ctx.fillStyle = stateRef.current.power > 25 ? '#10b981' : '#f43f5e';
    ctx.fill();

    // Blue/Red shoulders (launch pads)
    ctx.fillStyle = '#1d4ed8';
    ctx.beginPath();
    ctx.arc(180, 660, 32, Math.PI, 0);
    ctx.fill();

    ctx.fillStyle = '#b91c1c';
    ctx.beginPath();
    ctx.arc(720, 660, 32, Math.PI, 0);
    ctx.fill();

    // VHS Static glitch filter if tape active
    if (stateRef.current.frenzyActive) {
      ctx.fillStyle = 'rgba(234, 179, 8, 0.04)';
      ctx.fillRect(0, 0, w, h);
      
      // Horizontal white tracking lines
      const yLine = (performance.now() * 0.2) % h;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.fillRect(0, yLine, w, 3);
    }

    // 11. DRAW THE JUMPSCARE FULL SCREEN IMAGE (IF TRIGGERED)
    if (stateRef.current.jumpscareTimer > 0 && stateRef.current.jumpscareMonster) {
      ctx.save();
      ctx.fillStyle = 'rgba(10, 0, 0, 0.85)';
      ctx.fillRect(0, 0, w, h);

      // Red vignette flash
      const pulseVal = Math.sin(performance.now() * 0.05);
      const vignetteGrad = ctx.createRadialGradient(w/2, h/2, 100, w/2, h/2, w/2);
      vignetteGrad.addColorStop(0, 'rgba(0,0,0,0)');
      vignetteGrad.addColorStop(1, `rgba(220, 38, 38, ${0.4 + pulseVal * 0.2})`);
      ctx.fillStyle = vignetteGrad;
      ctx.fillRect(0, 0, w, h);

      // Terrifying giant Huggy/Kissy face centered
      ctx.translate(w / 2 + (Math.random() - 0.5) * 45, h / 2 + (Math.random() - 0.5) * 45);
      
      const monType = stateRef.current.jumpscareMonster.type;
      const monsterColor = monType === 'huggy' ? '#1d4ed8' : monType === 'kissy' ? '#ec4899' : '#db2777';
      const lipColor = monType === 'huggy' ? '#ef4444' : '#db2777';

      // Giant head backdrop
      ctx.beginPath();
      ctx.arc(0, -60, 240, 0, Math.PI * 2);
      ctx.fillStyle = monsterColor;
      ctx.fill();

      // Huge popping bulging eyeballs
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(-80, -110, 50, 0, Math.PI * 2);
      ctx.arc(80, -110, 50, 0, Math.PI * 2);
      ctx.fill();

      // Tiny, pin-prick dilated pupils staring right at soul
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(-70 + (Math.random() - 0.5) * 8, -100 + (Math.random() - 0.5) * 8, 14, 0, Math.PI * 2);
      ctx.arc(90 + (Math.random() - 0.5) * 8, -105 + (Math.random() - 0.5) * 8, 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.arc(-70, -100, 6, 0, Math.PI * 2);
      ctx.arc(90, -105, 6, 0, Math.PI * 2);
      ctx.fill();

      // Giant gaping razor-sharp mouth taking over the screen
      ctx.beginPath();
      ctx.arc(0, 50, 130, 0, Math.PI, false);
      ctx.fillStyle = lipColor;
      ctx.fill();

      // Black pitch depth
      ctx.beginPath();
      ctx.arc(0, 50, 110, 0, Math.PI, false);
      ctx.fillStyle = '#000000';
      ctx.fill();

      // Multiple nested rows of yellow sharp needle teeth
      ctx.fillStyle = '#fef08a';
      for (let pass = 0; pass < 3; pass++) {
        const radOffset = pass * 12;
        for (let angle = 0.2; angle < Math.PI - 0.2; angle += 0.08) {
          const tx = Math.cos(angle) * (100 - radOffset);
          const ty = 50 + Math.sin(angle) * (100 - radOffset);
          ctx.beginPath();
          ctx.moveTo(tx, ty);
          ctx.lineTo(tx - 6, ty - 16);
          ctx.lineTo(tx + 6, ty - 16);
          ctx.fill();
        }
      }

      // Jumpscare Red Static lines
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.6)';
      ctx.lineWidth = 4;
      for (let i = 0; i < 6; i++) {
        const yLine = Math.random() * h - h / 2;
        ctx.beginPath();
        ctx.moveTo(-w/2, yLine);
        ctx.lineTo(w/2, yLine);
        ctx.stroke();
      }

      // TEXT SCREAM OVERLAY
      ctx.font = 'black 64px "Impact", sans-serif';
      ctx.fillStyle = '#f43f5e';
      ctx.textAlign = 'center';
      ctx.fillText("PLAYTIME IS OVER!", 0, -230);

      ctx.restore();
    }

    ctx.restore();
  };

  // Stretchy rope visual pathing with gravity / natural wiggle
  const drawCable = (ctx: CanvasRenderingContext2D, hand: GrabHand, baseColor: string, glowColor: string) => {
    if (hand.state === 'idle') return;

    ctx.save();
    ctx.lineWidth = 5;
    ctx.strokeStyle = baseColor;
    ctx.lineCap = 'round';

    const sx = hand.originX;
    const sy = hand.originY - 20;
    const ex = hand.x;
    const ey = hand.y;

    ctx.beginPath();
    ctx.moveTo(sx, sy);

    if (hand.state === 'shooting' || hand.state === 'returning') {
      // Smooth curve based on dynamic rope drag physics
      const midX = (sx + ex) / 2;
      const midY = (sy + ey) / 2 + Math.sin(hand.currentLength * 0.01) * 35;
      ctx.quadraticCurveTo(midX, midY, ex, ey);
    } else {
      // Stuck wire curves downwards naturally
      const controlY = Math.max(sy, ey) + 40;
      ctx.quadraticCurveTo((sx + ex) / 2, controlY, ex, ey);
    }
    ctx.stroke();

    // Outer electricity glow overlay
    ctx.lineWidth = 2;
    ctx.strokeStyle = glowColor;
    ctx.stroke();

    // If electricity completed, show animated energy pulses traveling down the cable!
    if (stateRef.current.blueSocket?.connected && stateRef.current.redSocket?.connected) {
      const pulseT = (performance.now() * 0.01) % 1;
      const px = sx + (ex - sx) * pulseT;
      const py = sy + (ey - sy) * pulseT + (hand.state === 'stuck' ? 20 : 0);
      ctx.beginPath();
      ctx.arc(px, py, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#60a5fa';
      ctx.fill();
    }

    ctx.restore();
  };

  // Draw GrabPack hand item
  const drawHandGraphic = (ctx: CanvasRenderingContext2D, hand: GrabHand) => {
    ctx.save();
    ctx.translate(hand.x, hand.y);

    // Aim rotation
    const angle = Math.atan2(hand.y - hand.originY, hand.x - hand.originX) + Math.PI / 2;
    ctx.rotate(angle);

    const isBlue = hand.color === 'blue';
    const primaryColor = isBlue ? '#2563eb' : '#dc2626';
    const accentColor = isBlue ? '#60a5fa' : '#f87171';

    // 1. Draw glowing palm plate
    ctx.fillStyle = primaryColor;
    ctx.beginPath();
    ctx.ellipse(0, 0, 18, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    // 2. Draw brass wrist collar
    ctx.fillStyle = '#fbbf24';
    ctx.fillRect(-10, 12, 20, 6);

    // 3. Draw segmented fingers
    ctx.fillStyle = primaryColor;
    ctx.strokeStyle = accentColor;
    ctx.lineWidth = 2;

    // Left Finger / Thumb
    ctx.beginPath();
    ctx.moveTo(-12, -4);
    ctx.quadraticCurveTo(-22, -18, -16, -26);
    ctx.lineTo(-11, -22);
    ctx.lineTo(-8, -4);
    ctx.fill();
    ctx.stroke();

    // Center Index Finger
    ctx.beginPath();
    ctx.moveTo(-5, -12);
    ctx.quadraticCurveTo(-6, -30, 0, -32);
    ctx.lineTo(5, -12);
    ctx.fill();
    ctx.stroke();

    // Right Finger
    ctx.beginPath();
    ctx.moveTo(12, -4);
    ctx.quadraticCurveTo(22, -18, 16, -26);
    ctx.lineTo(11, -22);
    ctx.lineTo(8, -4);
    ctx.fill();
    ctx.stroke();

    // 4. Center energy indicator orb
    ctx.beginPath();
    ctx.arc(0, 0, 5, 0, Math.PI * 2);
    ctx.fillStyle = hand.state === 'shooting' ? '#ffffff' : hand.state === 'stuck' ? '#fbbf24' : '#111827';
    ctx.fill();

    ctx.restore();
  };

  // Draw generic lightning line helper
  const drawLightningArc = (
    ctx: CanvasRenderingContext2D,
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    color: string
  ) => {
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    
    // Segmented spark zig-zag
    const midX = (x1 + x2) / 2 + (Math.random() - 0.5) * 15;
    const midY = (y1 + y2) / 2 + (Math.random() - 0.5) * 15;
    ctx.lineTo(midX, midY);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
  };

  // Toggle Pause
  const togglePause = () => {
    setIsPaused((prev) => !prev);
  };



  return (
    <div className="flex flex-col items-center justify-center bg-zinc-950 p-1 md:p-4 rounded-3xl border border-zinc-800 shadow-2xl overflow-hidden max-w-full">
      {/* Top Controller Bar */}
      <div className="w-full max-w-[900px] flex items-center justify-between mb-3 px-4 bg-zinc-900/60 py-3 rounded-xl border border-zinc-800/80">
        <div className="flex items-center gap-4">
          <div className="text-zinc-400 font-mono text-xs">
            <span className="block text-zinc-500 uppercase tracking-widest font-black">Employee</span>
            <span className="text-yellow-400 font-extrabold">{playerName || 'REC-91'}</span>
          </div>
          <div className="h-6 w-[1px] bg-zinc-800" />
          <div className="text-zinc-400 font-mono text-xs">
            <span className="block text-zinc-500 uppercase tracking-widest font-black">Difficulty</span>
            <span className={`font-extrabold uppercase ${
              difficulty === 'nightmare' ? 'text-red-500 animate-pulse' : difficulty === 'hard' ? 'text-amber-500' : 'text-blue-400'
            }`}>
              {difficulty}
            </span>
          </div>
        </div>

        {/* Dynamic Warning Indicator when Huggy is super close */}
        {stateRef.current.monsters.some(m => m.y > 350) && (
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-red-950/75 border border-red-500/30 text-red-400 rounded-lg animate-pulse text-xs font-black tracking-widest">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            INTRUSION DETECTED!
          </div>
        )}

        <div className="flex items-center gap-2">
          {/* Scanline toggle */}
          <button
            onClick={() => setScanlines(!scanlines)}
            className={`p-2 rounded-lg transition text-xs font-extrabold flex items-center gap-1.5 ${
              scanlines ? 'bg-indigo-600 text-white' : 'bg-zinc-800 text-zinc-400 hover:text-white'
            }`}
            title="Toggle VHS scanline overlay"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">CRT FILTER</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => onToggleMute(!isMuted)}
            className="p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded-lg transition"
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-green-400" />}
          </button>

          <button
            onClick={togglePause}
            className="p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded-lg transition flex items-center gap-1.5 font-bold text-xs"
          >
            {isPaused ? <Play className="w-3.5 h-3.5 text-green-500" /> : <Pause className="w-3.5 h-3.5 text-yellow-500" />}
            <span className="hidden sm:inline">{isPaused ? 'RESUME' : 'PAUSE'}</span>
          </button>

          <button
            onClick={onExit}
            className="p-2 bg-red-950/45 hover:bg-red-900/60 text-red-400 rounded-lg transition text-xs font-bold"
          >
            QUIT
          </button>
        </div>
      </div>

      {/* Main Canvas Container */}
      <div className="relative w-full aspect-[9/7] max-w-[900px] border-4 border-zinc-900 bg-black rounded-2xl shadow-inner overflow-hidden cursor-crosshair">
        
        {/* Canvas Element */}
        <canvas
          ref={canvasRef}
          onMouseMove={handleMouseMove}
          onMouseDown={handleCanvasMouseDown}
          onTouchStart={handleCanvasTouchStart}
          onContextMenu={handleContextMenu}
          className="w-full h-full object-cover block"
        />

        {/* Floating Scanlines Filter Layer */}
        {scanlines && (
          <div className="pointer-events-none absolute inset-0 bg-scanlines opacity-20" />
        )}

        {/* Vignette horror shadow border */}
        <div className="pointer-events-none absolute inset-0 shadow-[inset_0_0_80px_rgba(0,0,0,0.85)]" />

        {/* Static VHS Glitch Overlay (Active in Frenzy/VHS Mode) */}
        {frenzyActive && (
          <div className="pointer-events-none absolute inset-0 bg-noise opacity-15 mix-blend-color-dodge animate-[pulse_0.15s_infinite]" />
        )}

        {/* Real-time floating game stats */}
        <div className="absolute top-4 left-4 flex gap-4 pointer-events-none">
          {/* Current Score Display */}
          <div className="bg-zinc-950/80 border border-zinc-800/80 px-4 py-2 rounded-xl backdrop-blur-md">
            <span className="block text-[10px] text-zinc-500 uppercase tracking-widest font-black">Score</span>
            <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-amber-500 font-mono tracking-tight">
              {score.toLocaleString()}
            </span>
            {multiplier > 1 && (
              <span className="ml-2 inline-block text-[10px] bg-yellow-500 text-zinc-950 px-1.5 py-0.5 rounded font-black tracking-wide animate-pulse">
                x{multiplier} MULTIPLIER
              </span>
            )}
          </div>

          {/* Toys Assembled Counter */}
          <div className="bg-zinc-950/80 border border-zinc-800/80 px-4 py-2 rounded-xl backdrop-blur-md">
            <span className="block text-[10px] text-zinc-500 uppercase tracking-widest font-black">Toys Assembled</span>
            <span className="text-2xl font-black text-purple-400 font-mono tracking-tight">
              {toysCount}
            </span>
          </div>

          {/* Time Survived Counter */}
          <div className="hidden sm:block bg-zinc-950/80 border border-zinc-800/80 px-4 py-2 rounded-xl backdrop-blur-md">
            <span className="block text-[10px] text-zinc-500 uppercase tracking-widest font-black">Time Survived</span>
            <span className="text-2xl font-black text-zinc-300 font-mono tracking-tight">
              {timeElapsed}s
            </span>
          </div>
        </div>

        {/* Power Grid HUD (Top Right) */}
        <div className="absolute top-4 right-4 pointer-events-none">
          <div className="bg-zinc-950/80 border border-zinc-800/80 px-4 py-2 rounded-xl backdrop-blur-md w-44">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-black flex items-center gap-1">
                <Battery className={`w-3 h-3 ${power < 25 ? 'text-red-500 animate-pulse' : 'text-green-400'}`} />
                Power Grid
              </span>
              <span className={`text-xs font-mono font-black ${power < 25 ? 'text-red-500 animate-pulse' : 'text-green-400'}`}>
                {Math.floor(power)}%
              </span>
            </div>
            
            {/* Battery Level Meter Bar */}
            <div className="h-2 bg-zinc-800 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-150 ${
                  power < 25 ? 'bg-red-500 animate-pulse' : power < 55 ? 'bg-yellow-500' : 'bg-green-500'
                }`}
                style={{ width: `${power}%` }}
              />
            </div>
          </div>
        </div>

        {/* FRENZY ALERT BANNER (If Active) */}
        {frenzyActive && (
          <div className="absolute top-18 left-1/2 -translate-x-1/2 pointer-events-none bg-yellow-500 text-zinc-950 px-4 py-1.5 rounded-full shadow-lg border border-yellow-300 font-extrabold text-xs flex items-center gap-1.5 animate-bounce tracking-widest uppercase">
            <Zap className="w-3.5 h-3.5 fill-current animate-pulse" />
            VHS FRENZY MODE: {Math.max(0, Math.ceil(frenzyTime))}s REMAINING!
          </div>
        )}

        {/* Pause Screen Overlay */}
        {isPaused && (
          <div className="absolute inset-0 bg-zinc-950/90 backdrop-blur-sm flex flex-col items-center justify-center gap-4">
            <h3 className="text-4xl font-black text-white tracking-widest uppercase animate-pulse">Game Paused</h3>
            <p className="text-zinc-400 text-sm max-w-xs text-center leading-relaxed">
              Playtime Co. safety overrides active. Take a breather and grab your GrabPack handles when ready!
            </p>
            <div className="flex gap-3 mt-2">
              <button
                onClick={togglePause}
                className="px-6 py-2.5 rounded-xl bg-green-600 hover:bg-green-500 text-white font-extrabold shadow-lg transition flex items-center gap-2 text-sm uppercase"
              >
                <Play className="w-4 h-4 fill-current" />
                Resume Play
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Ergonomic & Comfortable Virtual Controller Triggers */}
      <div className="w-full max-w-[900px] mt-4 grid grid-cols-2 gap-4 p-3 bg-zinc-900/80 rounded-2xl border border-zinc-800 shadow-md">
        <button
          onClick={() => {
            // Comfortably fire Blue Hand at the left-side targets
            // Pick a reasonable left valve or left-side monster
            const leftMonster = stateRef.current.monsters.find(m => m.x < 450);
            const targetX = leftMonster ? leftMonster.x : 120;
            const targetY = leftMonster ? leftMonster.y : 180;
            fireHand('blue', targetX, targetY);
          }}
          className="group flex flex-col items-center justify-center py-4 px-6 rounded-xl bg-gradient-to-br from-blue-700 to-indigo-900 border-2 border-blue-500/40 hover:border-blue-400 active:scale-95 transition-all text-white font-extrabold shadow-lg"
          title="Fires Blue GrabPack hand toward hazards"
        >
          <span className="text-[10px] tracking-widest text-blue-300 font-mono uppercase mb-1">Left Trigger</span>
          <div className="flex items-center gap-2">
            <div className="w-5.5 h-5.5 rounded-full bg-blue-500 flex items-center justify-center font-black text-xs text-zinc-950 shadow-inner group-hover:scale-110 transition">
              L
            </div>
            <span className="text-sm tracking-wide">FIRE BLUE HAND</span>
          </div>
          <span className="text-[9px] text-blue-300/60 font-mono mt-1 font-medium">Automatic target left</span>
        </button>

        <button
          onClick={() => {
            // Comfortably fire Red Hand at the right-side targets
            const rightMonster = stateRef.current.monsters.find(m => m.x >= 450);
            const targetX = rightMonster ? rightMonster.x : 780;
            const targetY = rightMonster ? rightMonster.y : 180;
            fireHand('red', targetX, targetY);
          }}
          className="group flex flex-col items-center justify-center py-4 px-6 rounded-xl bg-gradient-to-br from-red-700 to-rose-950 border-2 border-red-500/40 hover:border-red-400 active:scale-95 transition-all text-white font-extrabold shadow-lg"
          title="Fires Red GrabPack hand toward hazards"
        >
          <span className="text-[10px] tracking-widest text-red-300 font-mono uppercase mb-1">Right Trigger</span>
          <div className="flex items-center gap-2">
            <div className="w-5.5 h-5.5 rounded-full bg-red-500 flex items-center justify-center font-black text-xs text-zinc-950 shadow-inner group-hover:scale-110 transition">
              R
            </div>
            <span className="text-sm tracking-wide">FIRE RED HAND</span>
          </div>
          <span className="text-[9px] text-red-300/60 font-mono mt-1 font-medium">Automatic target right</span>
        </button>
      </div>

      {/* Control Tutorial / Help Guide footer */}
      <div className="w-full max-w-[900px] mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-zinc-500 bg-zinc-900/40 p-4 rounded-xl border border-zinc-800/60">
        <div>
          <h4 className="font-extrabold text-zinc-300 uppercase tracking-wider mb-2 flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-yellow-500" />
            Desktop Keyboard/Mouse Controls:
          </h4>
          <ul className="space-y-1.5 list-disc pl-4 font-medium leading-relaxed">
            <li><strong className="text-blue-400">Left Click:</strong> Fire <span className="font-extrabold">BLUE</span> GrabPack Hand (At pointer).</li>
            <li><strong className="text-red-400">Right Click / Space / Shift:</strong> Fire <span className="font-extrabold">RED</span> GrabPack Hand (At pointer).</li>
            <li><strong className="text-zinc-400">Target Fuse Sockets:</strong> Fire Blue Hand at Left Blue Outlet & Red Hand at Right Red Outlet to trigger an <span className="text-yellow-400 font-extrabold">Electric Shock Wave</span> to fry all monsters on-screen!</li>
            <li><strong className="text-zinc-400">Monsters:</strong> Launch hands directly at monsters to push them back up the vents.</li>
          </ul>
        </div>

        <div>
          <h4 className="font-extrabold text-zinc-300 uppercase tracking-wider mb-2 flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            Mobile/Touch & Universal Help:
          </h4>
          <ul className="space-y-1.5 list-disc pl-4 font-medium leading-relaxed">
            <li><strong className="text-zinc-300">Tap Screen Left Half:</strong> Shoots <span className="text-blue-400 font-bold">Blue</span> GrabPack hand to that point.</li>
            <li><strong className="text-zinc-300">Tap Screen Right Half:</strong> Shoots <span className="text-red-400 font-bold">Red</span> GrabPack hand to that point.</li>
            <li><strong className="text-amber-400 font-bold">Power Cell (Batteries):</strong> Pull them in to keep the factory power online!</li>
            <li><strong className="text-purple-400 font-bold">Steam Valves:</strong> Grab red wheels on walls to blast hot steam and hold back intruders!</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
