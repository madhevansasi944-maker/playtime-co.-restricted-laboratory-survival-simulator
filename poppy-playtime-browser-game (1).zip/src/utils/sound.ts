// Web Audio API Sound Synthesizer for Poppy Playtime Game
class SoundManager {
  private ctx: AudioContext | null = null;
  private ambientOsc: OscillatorNode | null = null;
  private ambientGain: GainNode | null = null;
  private isMuted: boolean = false;

  constructor() {
    // Sound is initialized on first user interaction
  }

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  setMute(muted: boolean) {
    this.isMuted = muted;
    if (muted) {
      if (this.ambientGain) this.ambientGain.gain.setValueAtTime(0, this.ctx?.currentTime || 0);
    } else {
      if (this.ambientGain) this.ambientGain.gain.setValueAtTime(0.08, this.ctx?.currentTime || 0);
    }
  }

  getMuted() {
    return this.isMuted;
  }

  // Play a low spooky background rumble
  startAmbient() {
    try {
      this.init();
      if (!this.ctx || this.ambientOsc) return;

      const osc = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      // Deep rumble
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(45, this.ctx.currentTime); // 45 Hz hum
      
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(45.5, this.ctx.currentTime); // Slightly detuned for beating

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(120, this.ctx.currentTime);

      gain.gain.setValueAtTime(this.isMuted ? 0 : 0.08, this.ctx.currentTime);

      osc.connect(filter);
      osc2.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc2.start();

      this.ambientOsc = osc;
      this.ambientGain = gain;

      // Periodically trigger a spooky metal clang or wind howling in the background
      this.triggerSpookyCreakLoop();
    } catch (e) {
      console.warn("Audio Context failed to start:", e);
    }
  }

  stopAmbient() {
    if (this.ambientOsc) {
      try {
        this.ambientOsc.stop();
      } catch (e) {}
      this.ambientOsc = null;
    }
    if (this.ambientGain) {
      this.ambientGain.disconnect();
      this.ambientGain = null;
    }
  }

  private triggerSpookyCreakLoop() {
    if (!this.ambientOsc || this.isMuted) return;

    // Trigger a creepy sound every 10-15 seconds
    setTimeout(() => {
      if (this.ambientOsc && !this.isMuted) {
        this.playCreak();
        this.triggerSpookyCreakLoop();
      }
    }, 8000 + Math.random() * 8000);
  }

  playCreak() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      osc.type = 'triangle';
      // Creaking metallic sound sliding pitch
      osc.frequency.setValueAtTime(100, now);
      osc.frequency.exponentialRampToValueAtTime(180, now + 1.5);
      osc.frequency.exponentialRampToValueAtTime(60, now + 3.0);

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(400, now);
      filter.Q.setValueAtTime(4.0, now);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.04, now + 0.5);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.0);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(now + 3.0);
    } catch (e) {}
  }

  // Shoot GrabPack hand
  playShoot() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(120, now);
      osc.frequency.exponentialRampToValueAtTime(450, now + 0.15);
      osc.frequency.exponentialRampToValueAtTime(80, now + 0.35);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(now + 0.36);
    } catch (e) {}
  }

  // Grab something successfully
  playGrab() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      // Metal hit clank
      const osc = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(330, now);
      osc.frequency.exponentialRampToValueAtTime(150, now + 0.15);

      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(110, now);
      osc2.frequency.exponentialRampToValueAtTime(50, now + 0.2);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc2.start();
      osc.stop(now + 0.3);
      osc2.stop(now + 0.3);
    } catch (e) {}
  }

  // Electric arc zap
  playElectricZap() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      
      // Let's make crackling spark sounds with White Noise
      const bufferSize = this.ctx.sampleRate * 0.25; // 0.25 seconds
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noiseNode = this.ctx.createBufferSource();
      noiseNode.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1800, now);

      // Add a rapid buzz oscillator
      const buzz = this.ctx.createOscillator();
      buzz.type = 'sawtooth';
      buzz.frequency.setValueAtTime(140, now);

      const buzzGain = this.ctx.createGain();
      buzzGain.gain.setValueAtTime(0.12, now);

      const finalGain = this.ctx.createGain();
      finalGain.gain.setValueAtTime(0.18, now);
      // Fast amplitude modulation to sound like crackling sparks
      for (let t = 0; t < 0.25; t += 0.02) {
        finalGain.gain.setValueAtTime(0.08 + Math.random() * 0.15, now + t);
      }
      finalGain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      noiseNode.connect(filter);
      filter.connect(finalGain);

      buzz.connect(buzzGain);
      buzzGain.connect(finalGain);

      finalGain.connect(this.ctx.destination);

      noiseNode.start();
      buzz.start();
      
      noiseNode.stop(now + 0.26);
      buzz.stop(now + 0.26);
    } catch (e) {}
  }

  // Battery charge pickup sound
  playBatteryCharge() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.setValueAtTime(554.37, now + 0.08); // Major chord arpeggio
      osc.frequency.setValueAtTime(659.25, now + 0.16);
      osc.frequency.setValueAtTime(880, now + 0.24);

      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(220, now);
      osc2.frequency.exponentialRampToValueAtTime(440, now + 0.35);

      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc2.start();
      osc.stop(now + 0.45);
      osc2.stop(now + 0.45);
    } catch (e) {}
  }

  // Toy pickup chime
  playToyChime() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(1500, now + 0.1);
      osc.frequency.exponentialRampToValueAtTime(1000, now + 0.25);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(now + 0.3);
    } catch (e) {}
  }

  // Sound for releasing hot steam blast
  playSteamBlast() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      const bufferSize = this.ctx.sampleRate * 0.4; // 0.4s hiss
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }

      const noiseNode = this.ctx.createBufferSource();
      noiseNode.buffer = buffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1200, now);
      filter.frequency.exponentialRampToValueAtTime(400, now + 0.4);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

      noiseNode.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noiseNode.start();
      noiseNode.stop(now + 0.41);
    } catch (e) {}
  }

  // Jumpscare scream!
  playJumpscare() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;

      // 1. Horrifying distorted bass roar
      const osc1 = this.ctx.createOscillator();
      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(70, now);
      osc1.frequency.linearRampToValueAtTime(35, now + 1.2);

      // 2. High pitched screeching metal
      const osc2 = this.ctx.createOscillator();
      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(220, now);
      osc2.frequency.linearRampToValueAtTime(1400, now + 0.5);
      osc2.frequency.exponentialRampToValueAtTime(200, now + 1.2);

      // 3. Shrill whistle
      const osc3 = this.ctx.createOscillator();
      osc3.type = 'square';
      osc3.frequency.setValueAtTime(900, now);
      osc3.frequency.setValueAtTime(1200, now + 0.15);
      osc3.frequency.setValueAtTime(800, now + 0.3);

      // 4. White noise roar
      const bufferSize = this.ctx.sampleRate * 1.5;
      const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = this.ctx.createBufferSource();
      noise.buffer = buffer;

      const noiseFilter = this.ctx.createBiquadFilter();
      noiseFilter.type = 'bandpass';
      noiseFilter.frequency.setValueAtTime(800, now);

      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(0.4, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 1.4);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.5, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.5);

      osc1.connect(gain);
      osc2.connect(gain);
      osc3.connect(gain);

      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(this.ctx.destination);

      gain.connect(this.ctx.destination);

      osc1.start();
      osc2.start();
      osc3.start();
      noise.start();

      osc1.stop(now + 1.5);
      osc2.stop(now + 1.5);
      osc3.stop(now + 1.5);
      noise.stop(now + 1.5);
    } catch (e) {}
  }

  // Level up or high score break
  playPowerRestore() {
    try {
      this.init();
      if (!this.ctx || this.isMuted) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(600, now + 0.2);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.4);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(now + 0.5);
    } catch (e) {}
  }
}

export const sound = new SoundManager();
