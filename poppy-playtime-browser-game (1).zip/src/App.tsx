import { useState, useEffect } from 'react';
import StartScreen from './components/StartScreen';
import GrabPackGame from './components/GrabPackGame';
import GameOver from './components/GameOver';
import HighScores from './components/HighScores';
import { Shield, Volume2, VolumeX, Terminal, Info, Trophy, Ghost } from 'lucide-react';
import { sound } from './utils/sound';

export default function App() {
  const [gameState, setGameState] = useState<'start' | 'playing' | 'gameover' | 'highscores'>('start');
  const [playerName, setPlayerName] = useState('REC-91');
  const [difficulty, setDifficulty] = useState<'normal' | 'hard' | 'nightmare'>('normal');
  const [isMuted, setIsMuted] = useState(false);

  // Stats from the completed run
  const [runStats, setRunStats] = useState({
    score: 0,
    timeSurvived: 0,
    toysAssembled: 0,
  });

  // Track page title for Poppy Playtime immersion
  useEffect(() => {
    document.title = "Poppy Playtime: GrabPack Overload";
  }, []);

  const handleStartGame = (name: string, diff: 'normal' | 'hard' | 'nightmare') => {
    setPlayerName(name);
    setDifficulty(diff);
    setGameState('playing');
  };

  const handleGameOver = (finalScore: number, timeSurvived: number, toysAssembled: number) => {
    setRunStats({
      score: finalScore,
      timeSurvived,
      toysAssembled,
    });
    setGameState('gameover');
  };

  const handleToggleMute = (muted: boolean) => {
    setIsMuted(muted);
    sound.setMute(muted);
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col items-center justify-between p-4 relative overflow-x-hidden selection:bg-yellow-500 selection:text-zinc-950">
      
      {/* Background neon light aura */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-red-600/5 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header Branding Banner */}
      <header className="w-full max-w-5xl flex flex-col md:flex-row items-center justify-between gap-4 py-4 border-b border-zinc-900 mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center shadow-lg border border-blue-500/20 shadow-blue-500/10">
            <Ghost className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-widest text-white uppercase flex items-center gap-2">
              PLAYTIME CO.
              <span className="text-[10px] bg-red-600 text-white font-extrabold px-1.5 py-0.5 rounded tracking-normal">
                RESTRICTED
              </span>
            </h1>
            <p className="text-xs text-zinc-500 font-mono">LABORATORY SURVIVAL SIMULATOR</p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono text-zinc-500">
          <span className="hidden sm:flex items-center gap-1">
            <Terminal className="w-4 h-4 text-green-500" />
            SEC-SYS STATUS: <span className="text-green-400 font-extrabold">READY</span>
          </span>
          <span className="hidden md:flex items-center gap-1">
            <Shield className="w-4 h-4 text-blue-500" />
            HARDWARE: <span className="text-blue-400 font-extrabold">GRABPACK v2</span>
          </span>
          <button
            onClick={() => handleToggleMute(!isMuted)}
            className="flex items-center gap-1 px-3 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded-lg text-zinc-300 transition"
          >
            {isMuted ? (
              <>
                <VolumeX className="w-3.5 h-3.5 text-red-400" />
                Muted
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5 text-green-400" />
                Audio ON
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-5xl flex items-center justify-center py-4">
        {gameState === 'start' && (
          <StartScreen
            onStartGame={handleStartGame}
            onViewHighScores={() => setGameState('highscores')}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
          />
        )}

        {gameState === 'playing' && (
          <GrabPackGame
            difficulty={difficulty}
            playerName={playerName}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onGameOver={handleGameOver}
            onExit={() => setGameState('start')}
          />
        )}

        {gameState === 'gameover' && (
          <GameOver
            score={runStats.score}
            timeSurvived={runStats.timeSurvived}
            toysAssembled={runStats.toysAssembled}
            difficulty={difficulty}
            playerName={playerName}
            onRestart={() => setGameState('playing')}
            onGoHome={() => setGameState('start')}
            onViewHighScores={() => setGameState('highscores')}
          />
        )}

        {gameState === 'highscores' && (
          <HighScores
            currentScore={runStats.score}
            onClose={() => setGameState('start')}
          />
        )}
      </main>

      {/* Spooky Footer Warn Banner & Specs */}
      <footer className="w-full max-w-5xl text-center py-6 mt-8 border-t border-zinc-900 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-zinc-500 font-mono">
        <p className="flex items-center justify-center gap-1.5">
          <Info className="w-4 h-4 text-yellow-500" />
          DO NOT OPEN TOY STORAGE AFTER HOURS. FOR REGISTERED EMPLOYEES ONLY.
        </p>
        
        <div className="flex gap-4">
          <button
            onClick={() => setGameState('highscores')}
            className="hover:text-yellow-400 transition flex items-center gap-1 font-bold"
          >
            <Trophy className="w-3.5 h-3.5" />
            Archives Ledger
          </button>
          <span>|</span>
          <p>© 2026 PLAYTIME CO. INDUSTRIAL SIMULATOR</p>
        </div>
      </footer>
    </div>
  );
}
